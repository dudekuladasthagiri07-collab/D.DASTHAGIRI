package com.example.security

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale

object SecurityUtils {

    fun generateSalt(): String {
        val random = SecureRandom()
        val saltBytes = ByteArray(16)
        random.nextBytes(saltBytes)
        return saltBytes.joinToString("") { "%02x".format(it) }
    }

    fun hashPassword(password: String, salt: String): String {
        val input = "$password:$salt"
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(input.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun verifyPassword(providedPassword: String, storedHash: String, storedSalt: String): Boolean {
        val directMatch = hashPassword(providedPassword, storedSalt) == storedHash
        if (directMatch) return true
        val normalized = normalizeDob(providedPassword)
        return hashPassword(normalized, storedSalt) == storedHash
    }

    /**
     * Normalizes date of birth for comparison if user enters with dashes or slashes.
     * e.g., "15/08/2004" -> "15-08-2004"
     */
    fun normalizeDob(dob: String): String {
        return dob.trim().replace("/", "-").replace(".", "-")
    }
}
