package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BranchId
import com.example.data.model.StudentEntity
import com.example.data.model.UnitTestResultEntity
import com.example.ui.components.SubjectUnitTestComparison
import com.example.ui.components.UnitTestComparisonBarChart
import com.example.ui.components.UnitTestTrendChart
import com.example.ui.viewmodel.CollegeViewModel
import kotlin.math.abs

/**
 * Benchmark data provider for calculating class averages and highest scores
 * across the 5 unit tests for each subject.
 */
object UnitTestBenchmarkProvider {
    /**
     * Calculates deterministic, realistic class average for a subject in a given unit test (1..5).
     * Typically between 13.5 and 16.5 marks out of 20.
     */
    fun getClassAverage(subjectCode: String, utIndex: Int): Double {
        val hash = (subjectCode.hashCode() * 17 + utIndex * 37).let { if (it < 0) -it else it }
        val variation = (hash % 30) / 10.0 // 0.0 to 2.9
        val base = 13.8 + variation // 13.8 to 16.7
        return (Math.round(base * 10.0) / 10.0).coerceIn(12.0, 18.0)
    }

    /**
     * Returns the highest score in the class cohort for that subject and unit test.
     */
    fun getClassHighest(subjectCode: String, utIndex: Int): Double {
        val hash = (subjectCode.hashCode() * 13 + utIndex * 19).let { if (it < 0) -it else it }
        return if (hash % 3 == 0) 20.0 else 19.5
    }

    /**
     * Builds comparison items between the student and class benchmark for the selected unit test.
     */
    fun buildComparisonList(
        unitTests: List<UnitTestResultEntity>,
        utIndex: Int // 1..5
    ): List<SubjectUnitTestComparison> {
        return unitTests.map { test ->
            val score = when (utIndex) {
                1 -> test.ut1Marks
                2 -> test.ut2Marks
                3 -> test.ut3Marks
                4 -> test.ut4Marks
                5 -> test.ut5Marks
                else -> test.ut1Marks
            }
            val classAvg = getClassAverage(test.subjectCode, utIndex)
            val classHigh = getClassHighest(test.subjectCode, utIndex)
            SubjectUnitTestComparison(
                subjectCode = test.subjectCode,
                subjectName = test.subjectName,
                studentScore = score,
                classAverage = classAvg,
                classHighest = classHigh,
                maxMarks = test.maxMarks
            )
        }
    }
}

/**
 * UnitTestScreen presents a tabbed/toggle view for each of the five unit tests,
 * using a bar chart to visualize marks against class averages alongside
 * subject breakdown and overall trajectory.
 */
@Composable
fun UnitTestScreen(
    student: StudentEntity,
    viewModel: CollegeViewModel,
    modifier: Modifier = Modifier
) {
    val branch = BranchId.fromCode(student.branchId)
    val unitTests by viewModel.unitTestList.collectAsState()

    // 0 = UT 1, 1 = UT 2, 2 = UT 3, 3 = UT 4, 4 = UT 5, 5 = Overview
    var selectedTabIndex by remember { mutableIntStateOf(0) }

    val overallTotalObtained = unitTests.sumOf { it.totalMarks }
    val overallMaxMarks = unitTests.sumOf { it.maxTotalMarks }
    val overallPercentage = if (overallMaxMarks > 0) (overallTotalObtained / overallMaxMarks) * 100.0 else 0.0

    val scrollState = rememberScrollState()

    val tabTitles = listOf("UT 1", "UT 2", "UT 3", "UT 4", "UT 5", "All UT Summary")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Overview Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.School,
                            contentDescription = null,
                            tint = branch.primaryColor,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "INTERNAL CONTINUOUS EVALUATION",
                            style = MaterialTheme.typography.labelMedium.copy(
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            color = branch.primaryColor
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Unit Tests & Class Benchmark",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Evaluated through 5 unit tests per semester (20 marks each). Track your marks against cohort class averages.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = branch.primaryColor.copy(alpha = 0.12f)
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Cumulative",
                            style = MaterialTheme.typography.labelSmall,
                            color = branch.primaryColor
                        )
                        Text(
                            text = "%.1f%%".format(overallPercentage),
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = branch.primaryColor
                        )
                        Text(
                            text = "%.1f/%.0f".format(overallTotalObtained, overallMaxMarks),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Tabbed View / Toggle for each of the five unit tests
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "Select Assessment Test",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                )

                ScrollableTabRow(
                    selectedTabIndex = selectedTabIndex,
                    edgePadding = 0.dp,
                    containerColor = Color.Transparent,
                    contentColor = branch.primaryColor,
                    indicator = { tabPositions ->
                        if (selectedTabIndex < tabPositions.size) {
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                                color = branch.primaryColor,
                                height = 3.dp
                            )
                        }
                    },
                    divider = {}
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        val isSelected = selectedTabIndex == index
                        Tab(
                            selected = isSelected,
                            onClick = { selectedTabIndex = index },
                            modifier = Modifier.testTag("ut_tab_$index"),
                            text = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (index < 5) Icons.Default.Equalizer else Icons.Default.Analytics,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (isSelected) branch.primaryColor else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                        ),
                                        color = if (isSelected) branch.primaryColor else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        )
                    }
                }

                // Quick Toggle Chips Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(top = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    tabTitles.forEachIndexed { index, title ->
                        val isSelected = selectedTabIndex == index
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedTabIndex = index },
                            label = {
                                Text(
                                    text = if (index < 5) "Unit Test ${index + 1}" else "Trajectory Summary",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = branch.primaryColor.copy(alpha = 0.15f),
                                selectedLabelColor = branch.primaryColor
                            ),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                }
            }
        }

        // Tab Content Display
        if (selectedTabIndex in 0..4) {
            val utNumber = selectedTabIndex + 1
            val comparisons = remember(unitTests, utNumber) {
                UnitTestBenchmarkProvider.buildComparisonList(unitTests, utNumber)
            }

            val studentAvg = if (comparisons.isNotEmpty()) comparisons.map { it.studentScore }.average() else 0.0
            val classAvg = if (comparisons.isNotEmpty()) comparisons.map { it.classAverage }.average() else 0.0
            val diff = studentAvg - classAvg

            // UT Status Header Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = branch.primaryColor.copy(alpha = 0.08f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = branch.primaryColor
                            ) {
                                Text(
                                    text = "UT $utNumber",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }

                            Text(
                                text = "Assessment Cycle $utNumber",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Continuous test covering Module $utNumber syllabus across all departmental subjects. Maximum 20 marks.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(horizontalAlignment = Alignment.End) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (diff >= 0) Color(0xFFD1FAE5) else Color(0xFFFEE2E2)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (diff >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                    contentDescription = null,
                                    tint = if (diff >= 0) Color(0xFF065F46) else Color(0xFF991B1B),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (diff >= 0) "+%.1f Above Avg".format(diff) else "%.1f Below Avg".format(diff),
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = if (diff >= 0) Color(0xFF065F46) else Color(0xFF991B1B)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Class Avg: %.1f/20".format(classAvg),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Grouped Bar Chart Visualizing Marks vs Class Averages
            UnitTestComparisonBarChart(
                comparisons = comparisons,
                testTitle = "Unit Test $utNumber",
                accentColor = branch.primaryColor,
                classAverageColor = branch.secondaryColor
            )

            // Subject-by-Subject Breakdown Cards for this specific Unit Test
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Subject Marks Breakdown (UT $utNumber)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${comparisons.size} Subjects",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                comparisons.forEach { comp ->
                    SubjectComparisonCard(
                        comparison = comp,
                        accentColor = branch.primaryColor,
                        secondaryColor = branch.secondaryColor
                    )
                }
            }
        } else {
            // "All UT Summary" Tab: Performance trajectory chart across UT 1 to 5 + Full Table
            UnitTestTrendChart(
                unitTests = unitTests,
                accentColor = branch.primaryColor
            )

            // Comprehensive Subject-wise Unit Test Marks Table
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Comprehensive Unit Test Marks (1 to 5)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${unitTests.size} Subjects",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("unit_test_table_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    val horizontalScroll = rememberScrollState()

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(horizontalScroll)
                    ) {
                        // Header row with separate columns for UT 1, 2, 3, 4, 5
                        Row(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TableCell(text = "Subject Code & Name", width = 230.dp, isHeader = true)
                            TableCell(text = "UT 1 (20)", width = 75.dp, isHeader = true)
                            TableCell(text = "UT 2 (20)", width = 75.dp, isHeader = true)
                            TableCell(text = "UT 3 (20)", width = 75.dp, isHeader = true)
                            TableCell(text = "UT 4 (20)", width = 75.dp, isHeader = true)
                            TableCell(text = "UT 5 (20)", width = 75.dp, isHeader = true)
                            TableCell(text = "Total (100)", width = 85.dp, isHeader = true)
                            TableCell(text = "Average (20)", width = 90.dp, isHeader = true)
                            TableCell(text = "Percentage", width = 95.dp, isHeader = true)
                            TableCell(text = "Rating", width = 100.dp, isHeader = true)
                        }

                        // Table Data Rows
                        unitTests.forEachIndexed { index, test ->
                            val pct = test.percentage
                            val rowBg = if (index % 2 == 0) {
                                MaterialTheme.colorScheme.surface
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                            }

                            Row(
                                modifier = Modifier
                                    .background(rowBg)
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.width(230.dp)) {
                                    Text(
                                        text = test.subjectName,
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                        maxLines = 2
                                    )
                                    Text(
                                        text = test.subjectCode,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = branch.primaryColor
                                    )
                                }

                                TableCell(text = "%.1f".format(test.ut1Marks), width = 75.dp)
                                TableCell(text = "%.1f".format(test.ut2Marks), width = 75.dp)
                                TableCell(text = "%.1f".format(test.ut3Marks), width = 75.dp)
                                TableCell(text = "%.1f".format(test.ut4Marks), width = 75.dp)
                                TableCell(text = "%.1f".format(test.ut5Marks), width = 75.dp)
                                TableCell(text = "%.1f".format(test.totalMarks), width = 85.dp)
                                TableCell(text = "%.2f".format(test.averageMarks), width = 90.dp)

                                // Percentage Pill
                                Box(modifier = Modifier.width(95.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = when {
                                            pct >= 85.0 -> Color(0xFFD1FAE5)
                                            pct >= 70.0 -> Color(0xFFE0E7FF)
                                            pct >= 50.0 -> Color(0xFFFEF3C7)
                                            else -> Color(0xFFFEE2E2)
                                        }
                                    ) {
                                        Text(
                                            text = "%.1f%%".format(pct),
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = when {
                                                pct >= 85.0 -> Color(0xFF065F46)
                                                pct >= 70.0 -> Color(0xFF3730A3)
                                                pct >= 50.0 -> Color(0xFF92400E)
                                                else -> Color(0xFF991B1B)
                                            },
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                        )
                                    }
                                }

                                // Rating Status
                                val rating = when {
                                    pct >= 90.0 -> "Outstanding"
                                    pct >= 80.0 -> "Very Good"
                                    pct >= 70.0 -> "Good"
                                    pct >= 50.0 -> "Pass"
                                    else -> "Remedial"
                                }
                                Text(
                                    text = rating,
                                    modifier = Modifier.width(100.dp),
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                    color = if (pct >= 70.0) Color(0xFF059669) else Color(0xFFD97706)
                                )
                            }
                        }

                        if (unitTests.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No Unit Test marks available.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Card displaying an individual subject's comparison metrics for the selected unit test.
 */
@Composable
private fun SubjectComparisonCard(
    comparison: SubjectUnitTestComparison,
    accentColor: Color,
    secondaryColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Subject header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = comparison.subjectName,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1
                    )
                    Text(
                        text = comparison.subjectCode,
                        style = MaterialTheme.typography.labelSmall,
                        color = accentColor
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (comparison.isAboveAverage) Color(0xFFD1FAE5) else Color(0xFFFEE2E2)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (comparison.isAboveAverage) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                            contentDescription = null,
                            tint = if (comparison.isAboveAverage) Color(0xFF065F46) else Color(0xFF991B1B),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (comparison.isAboveAverage) "+%.1f".format(comparison.difference) else "%.1f".format(comparison.difference),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (comparison.isAboveAverage) Color(0xFF065F46) else Color(0xFF991B1B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Score metrics comparison
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Student Score",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "%.1f / 20".format(comparison.studentScore),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = accentColor
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Class Average",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "%.1f / 20".format(comparison.classAverage),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                        color = secondaryColor
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Class Highest",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "%.1f / 20".format(comparison.classHighest),
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Visual linear progress indicator comparing student score to 20 marks
            LinearProgressIndicator(
                progress = { (comparison.studentScore / 20.0).toFloat().coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = accentColor,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}
