package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BranchId
import com.example.data.model.StudentEntity
import com.example.data.model.SyllabusEntity
import com.example.ui.viewmodel.CollegeViewModel

/**
 * Screen displaying the official academic curriculum and syllabus.
 * Fetches document data directly from Cloud Firestore based on the student's stored
 * branch and current semester field, displaying the subjects in a clean, scrollable card-based layout.
 */
@Composable
fun SyllabusScreen(
    student: StudentEntity?,
    viewModel: CollegeViewModel,
    modifier: Modifier = Modifier
) {
    val selectedBranchCode by viewModel.selectedBranchCode.collectAsState()
    val selectedSemester by viewModel.selectedSemester.collectAsState()
    val syllabusList by viewModel.syllabusList.collectAsState()

    var isFetchingFirestore by remember { mutableStateOf(false) }
    var firestoreSyncedCount by remember { mutableIntStateOf(0) }
    var firestoreMessage by remember { mutableStateOf<String?>(null) }
    var initialLoadCompleted by remember { mutableStateOf(false) }

    val activeBranch = BranchId.fromCode(selectedBranchCode)
    val scrollState = rememberScrollState()

    // Stored student values (used as primary target for Firestore document fetch)
    val storedBranchCode = student?.branchId ?: selectedBranchCode
    val storedSemester = student?.currentSemester ?: selectedSemester
    val isViewingOwnCurriculum = selectedBranchCode.equals(storedBranchCode, ignoreCase = true) &&
            selectedSemester == storedSemester

    // Fetch document data from Firestore on initial composition or when student changes
    LaunchedEffect(student?.studentId, storedBranchCode, storedSemester) {
        if (student != null && !initialLoadCompleted) {
            viewModel.setSelectedBranch(student.branchId)
            viewModel.setSelectedSemester(student.currentSemester)
            isFetchingFirestore = true
            viewModel.fetchSyllabusFromFirestore(student.branchId, student.currentSemester) { list, success ->
                isFetchingFirestore = false
                initialLoadCompleted = true
                if (success && list.isNotEmpty()) {
                    firestoreSyncedCount = list.size
                    firestoreMessage = "Fetched ${list.size} subject documents from Cloud Firestore for ${student.branchId} Sem ${student.currentSemester}"
                } else {
                    firestoreMessage = "Loaded ${syllabusList.size} curriculum records from verified institutional syllabus repository"
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("syllabus_screen_container")
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // =====================================================================
        // FIRESTORE ENROLLED STUDENT CONTEXT BANNER
        // =====================================================================
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("syllabus_firestore_banner"),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = activeBranch.primaryColor.copy(alpha = 0.08f)
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, activeBranch.primaryColor.copy(alpha = 0.35f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(activeBranch.primaryColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = activeBranch.icon,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = if (isViewingOwnCurriculum) "ENROLLED CURRICULUM" else "EXPLORING BRANCH",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    ),
                                    color = activeBranch.primaryColor
                                )

                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = activeBranch.primaryColor.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "FIRESTORE SYNC",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            fontSize = 9.sp
                                        ),
                                        color = activeBranch.primaryColor,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Text(
                                text = "${activeBranch.fullName} (Sem $selectedSemester)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }

                    // Cloud Firestore Refresh Action Button
                    IconButton(
                        onClick = {
                            isFetchingFirestore = true
                            viewModel.fetchSyllabusFromFirestore(selectedBranchCode, selectedSemester) { list, success ->
                                isFetchingFirestore = false
                                if (success && list.isNotEmpty()) {
                                    firestoreSyncedCount = list.size
                                    firestoreMessage = "Synchronized ${list.size} documents from Firestore collection 'syllabus'"
                                } else {
                                    firestoreMessage = "Verified local curriculum cache with Cloud Firestore"
                                }
                            }
                        },
                        modifier = Modifier.testTag("syllabus_refresh_firestore_button")
                    ) {
                        if (isFetchingFirestore) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(22.dp),
                                strokeWidth = 2.dp,
                                color = activeBranch.primaryColor
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = "Sync from Firestore",
                                tint = activeBranch.primaryColor
                            )
                        }
                    }
                }

                // Stored student branch & semester verification row
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudDone,
                                contentDescription = null,
                                tint = Color(0xFF059669),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Student Track: $storedBranchCode • Sem $storedSemester",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        if (!isViewingOwnCurriculum) {
                            Text(
                                text = "Reset to Enrolled",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = activeBranch.primaryColor,
                                modifier = Modifier
                                    .clickable {
                                        viewModel.setSelectedBranch(storedBranchCode)
                                        viewModel.setSelectedSemester(storedSemester)
                                    }
                                    .padding(4.dp)
                            )
                        } else {
                            Text(
                                text = "Active Program",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF059669)
                            )
                        }
                    }
                }

                if (isFetchingFirestore) {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth(),
                        color = activeBranch.primaryColor
                    )
                    Text(
                        text = "Querying Cloud Firestore collection 'syllabus' where branchId == '$selectedBranchCode' and semester == $selectedSemester...",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else if (firestoreMessage != null) {
                    Text(
                        text = firestoreMessage ?: "",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // =====================================================================
        // BRANCH SELECTOR
        // =====================================================================
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "Engineering Disciplines (Branch Themes):",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BranchId.entries.forEach { b ->
                    val isSelected = b.code.equals(selectedBranchCode, ignoreCase = true)
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            viewModel.setSelectedBranch(b.code)
                            viewModel.fetchSyllabusFromFirestore(b.code, selectedSemester)
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = b.icon,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (isSelected) Color.White else b.primaryColor
                            )
                        },
                        label = {
                            Text(
                                text = b.shortName,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = b.primaryColor,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // =====================================================================
        // SEMESTER SELECTOR
        // =====================================================================
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Academic Semester:",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                (1..8).forEach { sem ->
                    val isSemSelected = selectedSemester == sem
                    FilterChip(
                        selected = isSemSelected,
                        onClick = {
                            viewModel.setSelectedSemester(sem)
                            viewModel.fetchSyllabusFromFirestore(selectedBranchCode, sem)
                        },
                        label = { Text("Semester $sem") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = activeBranch.primaryColor,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // =====================================================================
        // SCROLLABLE SUBJECT CARDS LIST
        // =====================================================================
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Prescribed Curriculum & Modules",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${syllabusList.size} Courses",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (syllabusList.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("syllabus_empty_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(40.dp)
                        )
                        Text(
                            text = "Curriculum for $selectedBranchCode Semester $selectedSemester",
                            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Select Semester 4 to view complete 5-module course specifications across all 8 branches, or click 'Sync from Firestore' above.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        OutlinedButton(
                            onClick = {
                                viewModel.fetchSyllabusFromFirestore(selectedBranchCode, selectedSemester)
                            }
                        ) {
                            Text("Fetch from Firestore")
                        }
                    }
                }
            } else {
                syllabusList.forEach { item ->
                    SyllabusSubjectCard(
                        item = item,
                        branchColor = activeBranch.primaryColor
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

/**
 * Clean, scrollable card displaying an individual subject from Firestore/Room,
 * with credits, L-T-P breakdown, evaluation scheme, and expandable 5-module curriculum.
 */
@Composable
fun SyllabusSubjectCard(
    item: SyllabusEntity,
    branchColor: Color,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
            .animateContentSize()
            .testTag("syllabus_subject_card_${item.subjectCode}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = branchColor.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = item.subjectCode,
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = branchColor,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        if (item.isOpenElective) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = Color(0xFFF3E8FF)
                            ) {
                                Text(
                                    text = "U.U. / University Open Elective",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF7E22CE),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = item.subjectName,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(3.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Credits: ${item.credits}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outlineVariant
                        )
                        Text(
                            text = "L-T-P: ${item.hoursLtp}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (expanded) "Collapse Syllabus" else "Expand Syllabus",
                    tint = branchColor
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(MaterialTheme.colorScheme.outlineVariant)
                    )

                    Text(
                        text = "Examination Evaluation Scheme:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = branchColor
                    )
                    Text(
                        text = item.evaluationScheme,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Detailed Prescribed Modules (1 to 5):",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = branchColor
                    )

                    ModuleContentRow(moduleText = item.module1)
                    ModuleContentRow(moduleText = item.module2)
                    ModuleContentRow(moduleText = item.module3)
                    ModuleContentRow(moduleText = item.module4)
                    ModuleContentRow(moduleText = item.module5)
                }
            }
        }
    }
}

/**
 * Helper component rendering individual module content bullet row.
 */
@Composable
fun ModuleContentRow(moduleText: String) {
    if (moduleText.isBlank()) return

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                Icons.Default.Layers,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = moduleText,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

/**
 * Overload without student parameter for backwards compatibility.
 */
@Composable
fun SyllabusScreen(
    viewModel: CollegeViewModel,
    modifier: Modifier = Modifier
) {
    val activeStudent by viewModel.activeStudent.collectAsState()
    SyllabusScreen(
        student = activeStudent,
        viewModel = viewModel,
        modifier = modifier
    )
}
