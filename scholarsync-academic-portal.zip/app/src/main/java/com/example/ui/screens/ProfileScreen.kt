package com.example.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.example.data.model.StudentEntity
import com.example.ui.viewmodel.CollegeViewModel

/**
 * ProfileScreen delegates to UserProfileScreen to fulfill user requirements
 * for displaying Firestore-backed student details, branch, semester,
 * and authentication update password trigger.
 */
@Composable
fun ProfileScreen(
    student: StudentEntity,
    viewModel: CollegeViewModel,
    modifier: Modifier = Modifier
) {
    UserProfileScreen(
        student = student,
        viewModel = viewModel,
        modifier = modifier
    )
}
