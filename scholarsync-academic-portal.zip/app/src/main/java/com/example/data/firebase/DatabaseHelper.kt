package com.example.data.firebase

import android.util.Log
import com.example.data.model.AdminEntity
import com.example.data.model.AttendanceEntity
import com.example.data.model.SemesterResultEntity
import com.example.data.model.StudentEntity
import com.example.data.model.SyllabusEntity
import com.example.data.model.UnitTestResultEntity
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * DatabaseHelper for RGMCET Portal
 * Manages Cloud Firestore synchronization for Student, Admin, Attendance,
 * Unit Tests, Semester Results, and Syllabus data collections.
 */
object DatabaseHelper {

    private const val TAG = "RGMCET_DatabaseHelper"

    private var firestoreInstance: FirebaseFirestore? = null

    /**
     * Safely initializes and returns the Firestore instance.
     * Gracefully falls back if FirebaseApp is not yet configured with google-services.json.
     */
    fun getFirestore(): FirebaseFirestore? {
        if (firestoreInstance == null) {
            try {
                if (FirebaseApp.getApps(FirebaseApp.getInstance().applicationContext).isNotEmpty()) {
                    firestoreInstance = FirebaseFirestore.getInstance()
                }
            } catch (e: Exception) {
                try {
                    firestoreInstance = FirebaseFirestore.getInstance()
                } catch (e2: Exception) {
                    Log.w(TAG, "Firestore initialization fallback: ${e2.message}")
                }
            }
        }
        return firestoreInstance
    }

    val isFirestoreAvailable: Boolean
        get() = getFirestore() != null

    // =========================================================================
    // STUDENT COLLECTION OPERATIONS
    // =========================================================================

    suspend fun saveStudentToFirestore(student: StudentEntity): Boolean {
        val db = getFirestore() ?: return false
        return suspendCancellableCoroutine { continuation ->
            val data = hashMapOf(
                "studentId" to student.studentId,
                "name" to student.name,
                "dateOfBirth" to student.dateOfBirth,
                "passwordHash" to student.passwordHash,
                "salt" to student.salt,
                "isFirstLogin" to student.isFirstLogin,
                "branchId" to student.branchId,
                "currentSemester" to student.currentSemester,
                "email" to student.email,
                "phone" to student.phone,
                "enrollmentYear" to student.enrollmentYear,
                "cgpa" to student.cgpa,
                "college" to "RGMCET",
                "role" to "STUDENT",
                "updatedAt" to System.currentTimeMillis()
            )

            db.collection("students")
                .document(student.studentId)
                .set(data, SetOptions.merge())
                .addOnSuccessListener {
                    Log.d(TAG, "Student ${student.studentId} saved to Firestore")
                    if (continuation.isActive) continuation.resume(true)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Failed saving student to Firestore", e)
                    if (continuation.isActive) continuation.resume(false)
                }
        }
    }

    suspend fun getStudentFromFirestore(studentId: String): StudentEntity? {
        val db = getFirestore() ?: return null
        return suspendCancellableCoroutine { continuation ->
            db.collection("students")
                .document(studentId)
                .get()
                .addOnSuccessListener { doc ->
                    if (doc.exists()) {
                        val s = StudentEntity(
                            studentId = doc.getString("studentId") ?: studentId,
                            name = doc.getString("name") ?: "",
                            dateOfBirth = doc.getString("dateOfBirth") ?: "",
                            passwordHash = doc.getString("passwordHash") ?: "",
                            salt = doc.getString("salt") ?: "",
                            isFirstLogin = doc.getBoolean("isFirstLogin") ?: false,
                            branchId = doc.getString("branchId") ?: "CYBER",
                            currentSemester = (doc.getLong("currentSemester") ?: 4).toInt(),
                            email = doc.getString("email") ?: "",
                            phone = doc.getString("phone") ?: "",
                            enrollmentYear = (doc.getLong("enrollmentYear") ?: 2024).toInt(),
                            cgpa = doc.getDouble("cgpa") ?: 8.5
                        )
                        if (continuation.isActive) continuation.resume(s)
                    } else {
                        if (continuation.isActive) continuation.resume(null)
                    }
                }
                .addOnFailureListener {
                    if (continuation.isActive) continuation.resume(null)
                }
        }
    }

    // =========================================================================
    // ADMIN COLLECTION OPERATIONS
    // =========================================================================

    suspend fun saveAdminToFirestore(admin: AdminEntity): Boolean {
        val db = getFirestore() ?: return false
        return suspendCancellableCoroutine { continuation ->
            val data = hashMapOf(
                "adminId" to admin.adminId,
                "name" to admin.name,
                "passwordHash" to admin.passwordHash,
                "salt" to admin.salt,
                "email" to admin.email,
                "role" to "ADMIN",
                "college" to "RGMCET",
                "updatedAt" to System.currentTimeMillis()
            )

            db.collection("admins")
                .document(admin.adminId)
                .set(data, SetOptions.merge())
                .addOnSuccessListener {
                    Log.d(TAG, "Admin ${admin.adminId} saved to Firestore")
                    if (continuation.isActive) continuation.resume(true)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Failed saving admin to Firestore", e)
                    if (continuation.isActive) continuation.resume(false)
                }
        }
    }

    suspend fun getAdminFromFirestore(adminId: String): AdminEntity? {
        val db = getFirestore() ?: return null
        return suspendCancellableCoroutine { continuation ->
            db.collection("admins")
                .document(adminId)
                .get()
                .addOnSuccessListener { doc ->
                    if (doc.exists()) {
                        val a = AdminEntity(
                            adminId = doc.getString("adminId") ?: adminId,
                            name = doc.getString("name") ?: "",
                            passwordHash = doc.getString("passwordHash") ?: "",
                            salt = doc.getString("salt") ?: "",
                            email = doc.getString("email") ?: "admin@rgmcet.edu.in",
                            role = doc.getString("role") ?: "ADMIN"
                        )
                        if (continuation.isActive) continuation.resume(a)
                    } else {
                        if (continuation.isActive) continuation.resume(null)
                    }
                }
                .addOnFailureListener {
                    if (continuation.isActive) continuation.resume(null)
                }
        }
    }

    // =========================================================================
    // ROLE CHECKING
    // =========================================================================

    /**
     * Checks user role (ADMIN vs STUDENT vs UNKNOWN) by querying collections or email/ID patterns.
     */
    suspend fun checkUserRole(identifier: String): String {
        val cleanId = identifier.trim()

        // 1. Direct ID / prefix heuristics for RGMCET
        if (cleanId.startsWith("ADMIN", ignoreCase = true) || cleanId.equals("admin@rgmcet.edu.in", ignoreCase = true) || cleanId.contains("admin", ignoreCase = true)) {
            return "ADMIN"
        }

        // 2. Query Firestore admins collection
        val db = getFirestore()
        if (db != null) {
            val isAdminInDb = suspendCancellableCoroutine<Boolean> { continuation ->
                db.collection("admins")
                    .whereEqualTo("email", cleanId)
                    .limit(1)
                    .get()
                    .addOnSuccessListener { qs ->
                        if (continuation.isActive) continuation.resume(!qs.isEmpty)
                    }
                    .addOnFailureListener {
                        if (continuation.isActive) continuation.resume(false)
                    }
            }
            if (isAdminInDb) return "ADMIN"

            val isStudentInDb = suspendCancellableCoroutine<Boolean> { continuation ->
                db.collection("students")
                    .whereEqualTo("email", cleanId)
                    .limit(1)
                    .get()
                    .addOnSuccessListener { qs ->
                        if (continuation.isActive) continuation.resume(!qs.isEmpty)
                    }
                    .addOnFailureListener {
                        if (continuation.isActive) continuation.resume(false)
                    }
            }
            if (isStudentInDb) return "STUDENT"
        }

        return "STUDENT"
    }

    // =========================================================================
    // ACADEMIC DATA COLLECTIONS SYNC
    // =========================================================================

    suspend fun syncAttendanceList(list: List<AttendanceEntity>): Int {
        val db = getFirestore() ?: return 0
        var count = 0
        for (item in list) {
            val docId = "${item.studentId}_${item.subjectCode}"
            val data = hashMapOf(
                "studentId" to item.studentId,
                "subjectCode" to item.subjectCode,
                "subjectName" to item.subjectName,
                "totalClasses" to item.totalClasses,
                "attendedClasses" to item.attendedClasses,
                "previousMonthPercentage" to item.previousMonthPercentage,
                "monthlyHistoryCsv" to item.monthlyHistoryCsv,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("attendance").document(docId).set(data, SetOptions.merge())
            count++
        }
        return count
    }

    suspend fun syncUnitTestList(list: List<UnitTestResultEntity>): Int {
        val db = getFirestore() ?: return 0
        var count = 0
        for (item in list) {
            val docId = "${item.studentId}_${item.subjectCode}"
            val data = hashMapOf(
                "studentId" to item.studentId,
                "subjectCode" to item.subjectCode,
                "subjectName" to item.subjectName,
                "maxMarks" to item.maxMarks,
                "ut1Marks" to item.ut1Marks,
                "ut2Marks" to item.ut2Marks,
                "ut3Marks" to item.ut3Marks,
                "ut4Marks" to item.ut4Marks,
                "ut5Marks" to item.ut5Marks,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("unit_tests").document(docId).set(data, SetOptions.merge())
            count++
        }
        return count
    }

    suspend fun syncSemesterResultList(list: List<SemesterResultEntity>): Int {
        val db = getFirestore() ?: return 0
        var count = 0
        for (item in list) {
            val docId = "${item.studentId}_sem${item.semester}_${item.subjectCode}"
            val data = hashMapOf(
                "studentId" to item.studentId,
                "semester" to item.semester,
                "subjectCode" to item.subjectCode,
                "subjectName" to item.subjectName,
                "internalMarks" to item.internalMarks,
                "externalMarks" to item.externalMarks,
                "totalMarks" to item.totalMarks,
                "grade" to item.grade,
                "gradePoints" to item.gradePoints,
                "credits" to item.credits,
                "sgpa" to item.sgpa,
                "isOpenElective" to item.isOpenElective,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("semester_results").document(docId).set(data, SetOptions.merge())
            count++
        }
        return count
    }

    suspend fun syncSyllabusList(list: List<SyllabusEntity>): Int {
        val db = getFirestore() ?: return 0
        var count = 0
        for (item in list) {
            val docId = "${item.branchId}_sem${item.semester}_${item.subjectCode}"
            val data = hashMapOf(
                "branchId" to item.branchId,
                "semester" to item.semester,
                "subjectCode" to item.subjectCode,
                "subjectName" to item.subjectName,
                "credits" to item.credits,
                "hoursLtp" to item.hoursLtp,
                "isOpenElective" to item.isOpenElective,
                "module1" to item.module1,
                "module2" to item.module2,
                "module3" to item.module3,
                "module4" to item.module4,
                "module5" to item.module5,
                "evaluationScheme" to item.evaluationScheme,
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("syllabus").document(docId).set(data, SetOptions.merge())
            count++
        }
        return count
    }

    /**
     * Fetches syllabus documents from Firestore based on branch and semester.
     */
    suspend fun fetchSyllabusFromFirestore(branchId: String, semester: Int): List<SyllabusEntity> {
        val db = getFirestore() ?: return emptyList()
        return suspendCancellableCoroutine { continuation ->
            db.collection("syllabus")
                .whereEqualTo("branchId", branchId.uppercase())
                .whereEqualTo("semester", semester)
                .get()
                .addOnSuccessListener { snapshot ->
                    val results = mutableListOf<SyllabusEntity>()
                    for (doc in snapshot.documents) {
                        val item = SyllabusEntity(
                            branchId = doc.getString("branchId") ?: branchId,
                            semester = doc.getLong("semester")?.toInt() ?: semester,
                            subjectCode = doc.getString("subjectCode") ?: doc.id,
                            subjectName = doc.getString("subjectName") ?: "Subject",
                            credits = doc.getLong("credits")?.toInt() ?: 4,
                            hoursLtp = doc.getString("hoursLtp") ?: "3-1-0",
                            isOpenElective = doc.getBoolean("isOpenElective") ?: false,
                            module1 = doc.getString("module1") ?: "",
                            module2 = doc.getString("module2") ?: "",
                            module3 = doc.getString("module3") ?: "",
                            module4 = doc.getString("module4") ?: "",
                            module5 = doc.getString("module5") ?: "",
                            evaluationScheme = doc.getString("evaluationScheme") ?: "Internal Assessments (UT1-5: 20 marks), Mid-Sem (20 marks), End-Semester Exam (60 marks)."
                        )
                        results.add(item)
                    }
                    Log.d(TAG, "Fetched ${results.size} syllabus entries from Firestore for $branchId sem $semester")
                    if (continuation.isActive) continuation.resume(results)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "Error fetching syllabus from Firestore for $branchId sem $semester", e)
                    if (continuation.isActive) continuation.resume(emptyList())
                }
        }
    }
}
