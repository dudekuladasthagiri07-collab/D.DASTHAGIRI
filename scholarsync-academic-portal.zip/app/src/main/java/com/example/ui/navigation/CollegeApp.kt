package com.example.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.model.BranchId
import com.example.data.model.StudentEntity
import com.example.ui.components.BranchBadge
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AttendanceScreen
import com.example.ui.screens.FirstTimePasswordScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SemesterResultsScreen
import com.example.ui.screens.StudentDashboardScreen
import com.example.ui.screens.SyllabusScreen
import com.example.ui.screens.UnitTestScreen
import com.example.ui.screens.UserProfileScreen
import com.example.ui.theme.CollegePortalTheme
import com.example.ui.viewmodel.AuthState
import com.example.ui.viewmodel.CollegeViewModel

object CollegeDestinations {
    const val DASHBOARD = "dashboard"
    const val ATTENDANCE = "attendance"
    const val UNIT_TESTS = "unittests"
    const val RESULTS = "results"
    const val SYLLABUS = "syllabus"
    const val PROFILE = "profile"
}

data class NavigationItem(
    val label: String,
    val icon: ImageVector,
    val testTag: String,
    val route: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollegeApp(viewModel: CollegeViewModel) {
    val authState by viewModel.authState.collectAsState()
    val activeStudent by viewModel.activeStudent.collectAsState()

    val currentBranch = when {
        activeStudent != null -> BranchId.fromCode(activeStudent?.branchId ?: "")
        authState is AuthState.StudentLoggedIn -> BranchId.fromCode((authState as AuthState.StudentLoggedIn).student.branchId)
        else -> null
    }

    CollegePortalTheme(branch = currentBranch) {
        when (val state = authState) {
            is AuthState.LoggedOut -> {
                LoginScreen(viewModel = viewModel)
            }
            is AuthState.AdminLoggedIn -> {
                AdminPanelScreen(admin = state.admin, viewModel = viewModel)
            }
            is AuthState.StudentLoggedIn -> {
                val student = activeStudent ?: state.student
                if (state.requiresPasswordChange) {
                    FirstTimePasswordScreen(student = student, viewModel = viewModel)
                } else {
                    StudentMainScaffold(student = student, viewModel = viewModel)
                }
            }
        }
    }
}

/**
 * Main Screen Structure using Navigation Compose to manage views between
 * Dashboard, Attendance, Unit Tests, Results, Syllabus, and Profile.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentMainScaffold(
    student: StudentEntity,
    viewModel: CollegeViewModel
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: CollegeDestinations.DASHBOARD
    val branch = BranchId.fromCode(student.branchId)

    val navItems = listOf(
        NavigationItem("Dashboard", Icons.Default.Dashboard, "nav_dashboard", CollegeDestinations.DASHBOARD),
        NavigationItem("Attendance", Icons.Default.CalendarMonth, "nav_attendance", CollegeDestinations.ATTENDANCE),
        NavigationItem("Unit Tests", Icons.Default.Assignment, "nav_unittests", CollegeDestinations.UNIT_TESTS),
        NavigationItem("Results", Icons.Default.Grade, "nav_results", CollegeDestinations.RESULTS),
        NavigationItem("Syllabus", Icons.Default.MenuBook, "nav_syllabus", CollegeDestinations.SYLLABUS),
        NavigationItem("Profile", Icons.Default.Person, "nav_profile", CollegeDestinations.PROFILE)
    )

    val currentTitle = navItems.firstOrNull { it.route == currentRoute }?.label ?: "RGMCET Portal"

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = currentTitle,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                        BranchBadge(branchId = student.branchId)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.logout() },
                        modifier = Modifier.testTag("appbar_logout_button")
                    ) {
                        Icon(
                            Icons.Default.ExitToApp,
                            contentDescription = "Sign Out",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = branch.primaryColor
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                navItems.forEach { item ->
                    val isSelected = currentRoute == item.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            if (currentRoute != item.route) {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = {
                            Icon(
                                item.icon,
                                contentDescription = item.label,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        label = {
                            Text(
                                text = item.label,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                maxLines = 1
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = branch.primaryColor,
                            selectedTextColor = branch.primaryColor,
                            indicatorColor = branch.primaryColor.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier.testTag(item.testTag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = CollegeDestinations.DASHBOARD
            ) {
                composable(CollegeDestinations.DASHBOARD) {
                    StudentDashboardScreen(
                        student = student,
                        viewModel = viewModel,
                        onNavigateToTab = { tabIndex ->
                            val targetRoute = when (tabIndex) {
                                1 -> CollegeDestinations.ATTENDANCE
                                2 -> CollegeDestinations.UNIT_TESTS
                                3 -> CollegeDestinations.RESULTS
                                4 -> CollegeDestinations.SYLLABUS
                                5 -> CollegeDestinations.PROFILE
                                else -> CollegeDestinations.DASHBOARD
                            }
                            navController.navigate(targetRoute) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        onNavigateRoute = { routeName ->
                            navController.navigate(routeName) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
                composable(CollegeDestinations.ATTENDANCE) {
                    AttendanceScreen(student = student, viewModel = viewModel)
                }
                composable(CollegeDestinations.UNIT_TESTS) {
                    UnitTestScreen(student = student, viewModel = viewModel)
                }
                composable(CollegeDestinations.RESULTS) {
                    SemesterResultsScreen(student = student, viewModel = viewModel)
                }
                composable(CollegeDestinations.SYLLABUS) {
                    SyllabusScreen(student = student, viewModel = viewModel)
                }
                composable(CollegeDestinations.PROFILE) {
                    UserProfileScreen(student = student, viewModel = viewModel)
                }
            }
        }
    }
}
