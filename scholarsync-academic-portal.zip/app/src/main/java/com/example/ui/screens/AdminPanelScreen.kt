package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdminEntity
import com.example.data.model.AttendanceEntity
import com.example.data.model.BranchId
import com.example.data.model.SemesterResultEntity
import com.example.data.model.StudentEntity
import com.example.data.model.SyllabusEntity
import com.example.data.model.UnitTestResultEntity
import com.example.ui.components.BranchBadge
import com.example.ui.viewmodel.CollegeViewModel

@Composable
fun AdminPanelScreen(
    admin: AdminEntity,
    viewModel: CollegeViewModel,
    modifier: Modifier = Modifier
) {
    // Protected Access Verification: Ensure only users with ADMIN role can enter
    if (!admin.role.equals("ADMIN", ignoreCase = true)) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = null,
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(52.dp)
                    )
                    Text(
                        text = "Protected Access Violation",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    Text(
                        text = "Access to the RGMCET Administrator Console is strictly protected. Only authorized institutional administrators with accredited privileges may perform database operations.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF94A3B8),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Button(
                        onClick = { viewModel.logout() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                    ) {
                        Text("Return to Secure Login")
                    }
                }
            }
        }
        return
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    val allStudents by viewModel.allStudents.collectAsState()
    val allSyllabus by viewModel.allSyllabusList.collectAsState()

    var statusMessage by remember { mutableStateOf<String?>(null) }
    var showAddStudentDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Admin Header Banner with Protected Access & Firestore Indicator
        Surface(
            color = Color(0xFF0F172A),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF2563EB)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "RGMCET Admin Console",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0x3310B981)
                                ) {
                                    Text(
                                        text = "Protected Access",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = Color(0xFF6EE7B7),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "${admin.name} (${admin.adminId})",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }

                    IconButton(
                        onClick = { viewModel.logout() },
                        modifier = Modifier.testTag("admin_logout_button")
                    ) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "Sign out", tint = Color(0xFFF87171))
                    }
                }

                // Cloud Firestore Status Banner
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF1E293B),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                        )
                        Text(
                            text = "Cloud Firestore Synchronization: Active • Real-time Academic Store",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                            color = Color(0xFFCBD5E1)
                        )
                    }
                }
            }
        }

        // Sub Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            edgePadding = 12.dp
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Students Directory (${allStudents.size})") }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("Attendance Manager") }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("Unit Tests (1-5)") }
            )
            Tab(
                selected = selectedTab == 3,
                onClick = { selectedTab = 3 },
                text = { Text("Semester Results") }
            )
            Tab(
                selected = selectedTab == 4,
                onClick = { selectedTab = 4 },
                text = { Text("Syllabus Publisher") }
            )
        }

        // Action Status Message Banner
        AnimatedVisibility(visible = statusMessage != null) {
            Surface(
                color = Color(0xFFD1FAE5),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF065F46))
                    Text(
                        text = statusMessage ?: "",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFF065F46)
                    )
                }
            }
        }

        // Content Area
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            when (selectedTab) {
                0 -> AdminStudentsTab(
                    students = allStudents,
                    onAddStudent = { showAddStudentDialog = true },
                    onResetPassword = { studentId ->
                        viewModel.adminResetStudentPassword(studentId) { success ->
                            statusMessage = if (success) "Password for $studentId reset to Date of Birth!" else "Failed to reset password."
                        }
                    }
                )
                1 -> AdminAttendanceManagerTab(
                    students = allStudents,
                    onSave = { attendance ->
                        viewModel.adminSaveAttendance(attendance) {
                            statusMessage = "Attendance saved for ${attendance.studentId}!"
                        }
                    }
                )
                2 -> AdminUnitTestManagerTab(
                    students = allStudents,
                    onSave = { ut ->
                        viewModel.adminSaveUnitTest(ut) {
                            statusMessage = "Unit test marks recorded for ${ut.studentId}!"
                        }
                    }
                )
                3 -> AdminSemesterResultsTab(
                    students = allStudents,
                    onSave = { res ->
                        viewModel.adminSaveSemesterResult(res) {
                            statusMessage = "Semester result updated for ${res.studentId}!"
                        }
                    }
                )
                4 -> AdminSyllabusManagerTab(
                    syllabusList = allSyllabus,
                    onSave = { syl ->
                        viewModel.adminSaveSyllabus(syl) {
                            statusMessage = "Syllabus entry saved for ${syl.subjectCode}!"
                        }
                    },
                    onDelete = { syl ->
                        viewModel.adminDeleteSyllabus(syl)
                        statusMessage = "Syllabus entry deleted."
                    }
                )
            }
        }

        // Add Student Dialog
        if (showAddStudentDialog) {
            AddStudentDialog(
                onDismiss = { showAddStudentDialog = false },
                onConfirm = { id, name, dob, branch, sem, email, phone, cgpa ->
                    viewModel.adminCreateStudent(id, name, dob, branch, sem, email, phone, cgpa) { success, err ->
                        if (success) {
                            statusMessage = "New student $id ($name) created. Initial password set to DOB ($dob)."
                            showAddStudentDialog = false
                        } else {
                            statusMessage = "Error: $err"
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun AdminStudentsTab(
    students: List<StudentEntity>,
    onAddStudent: () -> Unit,
    onResetPassword: (String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var branchFilter by remember { mutableStateOf<String?>(null) }
    var studentToReset by remember { mutableStateOf<StudentEntity?>(null) }

    val filtered = students.filter {
        (branchFilter == null || it.branchId.equals(branchFilter, ignoreCase = true)) &&
                (it.name.contains(searchQuery, ignoreCase = true) || it.studentId.contains(searchQuery, ignoreCase = true))
    }

    val scrollState = rememberScrollState()

    // Confirmation dialog for resetting student password
    if (studentToReset != null) {
        val target = studentToReset!!
        AlertDialog(
            onDismissRequest = { studentToReset = null },
            icon = {
                Icon(
                    Icons.Default.LockReset,
                    contentDescription = null,
                    tint = Color(0xFFDC2626),
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text("Confirm Password Reset", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Are you sure you want to reset the login credentials for:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "${target.name} (${target.studentId})",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "The password will be reset back to their Date of Birth (${target.dateOfBirth}) in Cloud Firestore and the local SIS database. The student will be prompted to choose a new password on their next login.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onResetPassword(target.studentId)
                        studentToReset = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("Reset Password in Firestore")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { studentToReset = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Enrolled Students Database",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Cloud Firestore Collection: students",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = onAddStudent,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                modifier = Modifier.testTag("admin_add_student_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Student to Firestore")
            }
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by student name or roll number...") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        // Branch filter chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            FilterChip(
                selected = branchFilter == null,
                onClick = { branchFilter = null },
                label = { Text("All Branches") }
            )
            BranchId.entries.forEach { b ->
                FilterChip(
                    selected = branchFilter == b.code,
                    onClick = { branchFilter = b.code },
                    label = { Text(b.shortName) }
                )
            }
        }

        filtered.forEach { student ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = student.name,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            BranchBadge(branchId = student.branchId)
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = "Roll No: ${student.studentId} • Sem ${student.currentSemester} • CGPA: ${student.cgpa}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Text(
                            text = "DOB: ${student.dateOfBirth} ${if (student.isFirstLogin) "• [First-time DOB Pending]" else "• [Permanent Pass Active]"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (student.isFirstLogin) Color(0xFFD97706) else Color(0xFF059669)
                        )
                    }

                    OutlinedButton(
                        onClick = { studentToReset = student },
                        modifier = Modifier.testTag("reset_pass_${student.studentId}")
                    ) {
                        Icon(Icons.Default.LockReset, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset to DOB", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminAttendanceManagerTab(
    students: List<StudentEntity>,
    onSave: (AttendanceEntity) -> Unit
) {
    var selectedStudentId by remember { mutableStateOf(students.firstOrNull()?.studentId ?: "") }
    var subjectCode by remember { mutableStateOf("CS401") }
    var subjectName by remember { mutableStateOf("Database Management Systems") }
    var totalClasses by remember { mutableStateOf("54") }
    var attendedClasses by remember { mutableStateOf("48") }
    var prevMonthPct by remember { mutableStateOf("86.5") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Record / Modify Attendance Data",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        Text(
            text = "Select Student Roll Number:",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            students.forEach { st ->
                FilterChip(
                    selected = selectedStudentId == st.studentId,
                    onClick = { selectedStudentId = st.studentId },
                    label = { Text("${st.studentId} (${st.name.take(8)})") }
                )
            }
        }

        OutlinedTextField(
            value = subjectCode,
            onValueChange = { subjectCode = it },
            label = { Text("Subject Code") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = subjectName,
            onValueChange = { subjectName = it },
            label = { Text("Subject Name") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = totalClasses,
                onValueChange = { totalClasses = it },
                label = { Text("Total Classes") },
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = attendedClasses,
                onValueChange = { attendedClasses = it },
                label = { Text("Attended Classes") },
                modifier = Modifier.weight(1f)
            )
        }

        OutlinedTextField(
            value = prevMonthPct,
            onValueChange = { prevMonthPct = it },
            label = { Text("Previous-Month Attendance %") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                val total = totalClasses.toIntOrNull() ?: 50
                val attended = attendedClasses.toIntOrNull() ?: 40
                val prev = prevMonthPct.toDoubleOrNull() ?: 80.0
                val absent = (total - attended).coerceAtLeast(0)
                val pct = if (total > 0) (attended.toDouble() / total) * 100.0 else 0.0

                onSave(
                    AttendanceEntity(
                        studentId = selectedStudentId,
                        subjectCode = subjectCode.trim(),
                        subjectName = subjectName.trim(),
                        totalClasses = total,
                        attendedClasses = attended,
                        previousMonthPercentage = prev,
                        monthlyHistoryCsv = "75.0, 80.0, $prev, $pct"
                    )
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Save Attendance Record", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AdminUnitTestManagerTab(
    students: List<StudentEntity>,
    onSave: (UnitTestResultEntity) -> Unit
) {
    var selectedStudentId by remember { mutableStateOf(students.firstOrNull()?.studentId ?: "") }
    var subjectCode by remember { mutableStateOf("CS401") }
    var subjectName by remember { mutableStateOf("Database Management Systems") }
    var ut1 by remember { mutableStateOf("18.0") }
    var ut2 by remember { mutableStateOf("17.5") }
    var ut3 by remember { mutableStateOf("19.0") }
    var ut4 by remember { mutableStateOf("18.5") }
    var ut5 by remember { mutableStateOf("17.0") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Input Unit Test Marks (Columns UT 1 to 5)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            students.forEach { st ->
                FilterChip(
                    selected = selectedStudentId == st.studentId,
                    onClick = { selectedStudentId = st.studentId },
                    label = { Text("${st.studentId} (${st.name.take(8)})") }
                )
            }
        }

        OutlinedTextField(
            value = subjectCode,
            onValueChange = { subjectCode = it },
            label = { Text("Subject Code") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = subjectName,
            onValueChange = { subjectName = it },
            label = { Text("Subject Name") },
            modifier = Modifier.fillMaxWidth()
        )

        Text(text = "Unit Test Marks (Max 20 Each):", style = MaterialTheme.typography.labelMedium)

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = ut1, onValueChange = { ut1 = it }, label = { Text("UT 1") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = ut2, onValueChange = { ut2 = it }, label = { Text("UT 2") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = ut3, onValueChange = { ut3 = it }, label = { Text("UT 3") }, modifier = Modifier.weight(1f))
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = ut4, onValueChange = { ut4 = it }, label = { Text("UT 4") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = ut5, onValueChange = { ut5 = it }, label = { Text("UT 5") }, modifier = Modifier.weight(1f))
        }

        Button(
            onClick = {
                val m1 = ut1.toDoubleOrNull() ?: 15.0
                val m2 = ut2.toDoubleOrNull() ?: 15.0
                val m3 = ut3.toDoubleOrNull() ?: 15.0
                val m4 = ut4.toDoubleOrNull() ?: 15.0
                val m5 = ut5.toDoubleOrNull() ?: 15.0
                val total = m1 + m2 + m3 + m4 + m5
                val avg = total / 5.0
                val pct = (total / 100.0) * 100.0

                onSave(
                    UnitTestResultEntity(
                        studentId = selectedStudentId,
                        subjectCode = subjectCode.trim(),
                        subjectName = subjectName.trim(),
                        ut1Marks = m1,
                        ut2Marks = m2,
                        ut3Marks = m3,
                        ut4Marks = m4,
                        ut5Marks = m5
                    )
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Update Unit Test Marks", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AdminSemesterResultsTab(
    students: List<StudentEntity>,
    onSave: (SemesterResultEntity) -> Unit
) {
    var selectedStudentId by remember { mutableStateOf(students.firstOrNull()?.studentId ?: "") }
    var semester by remember { mutableStateOf("4") }
    var subjectCode by remember { mutableStateOf("CS401") }
    var subjectName by remember { mutableStateOf("Database Management Systems") }
    var internalMarks by remember { mutableStateOf("36") }
    var externalMarks by remember { mutableStateOf("54") }
    var grade by remember { mutableStateOf("A+") }
    var gradePoints by remember { mutableStateOf("9") }
    var credits by remember { mutableStateOf("4") }
    var isOpenElective by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Publish Semester Result & Grades",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            students.forEach { st ->
                FilterChip(
                    selected = selectedStudentId == st.studentId,
                    onClick = { selectedStudentId = st.studentId },
                    label = { Text("${st.studentId} (${st.name.take(8)})") }
                )
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value = semester, onValueChange = { semester = it }, label = { Text("Semester (1-8)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = subjectCode, onValueChange = { subjectCode = it }, label = { Text("Subject Code") }, modifier = Modifier.weight(1f))
        }

        OutlinedTextField(
            value = subjectName,
            onValueChange = { subjectName = it },
            label = { Text("Subject Name") },
            modifier = Modifier.fillMaxWidth()
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value = internalMarks, onValueChange = { internalMarks = it }, label = { Text("Internal (40)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = externalMarks, onValueChange = { externalMarks = it }, label = { Text("External (60)") }, modifier = Modifier.weight(1f))
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value = grade, onValueChange = { grade = it }, label = { Text("Grade (O, A+, A, etc.)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = gradePoints, onValueChange = { gradePoints = it }, label = { Text("Grade Points (0-10)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = credits, onValueChange = { credits = it }, label = { Text("Credits (3-4)") }, modifier = Modifier.weight(1f))
        }

        FilterChip(
            selected = isOpenElective,
            onClick = { isOpenElective = !isOpenElective },
            label = { Text("Is U.U. / Open Elective Subject") }
        )

        Button(
            onClick = {
                val sem = semester.toIntOrNull() ?: 4
                val iMarks = internalMarks.toIntOrNull() ?: 35
                val eMarks = externalMarks.toIntOrNull() ?: 50
                val total = iMarks + eMarks
                val gp = gradePoints.toIntOrNull() ?: 9
                val cr = credits.toIntOrNull() ?: 4

                onSave(
                    SemesterResultEntity(
                        studentId = selectedStudentId,
                        semester = sem,
                        subjectCode = subjectCode.trim(),
                        subjectName = subjectName.trim(),
                        internalMarks = iMarks,
                        externalMarks = eMarks,
                        totalMarks = total,
                        grade = grade.trim().uppercase(),
                        gradePoints = gp,
                        credits = cr,
                        sgpa = (gp * cr).toDouble() / cr.toDouble(),
                        isOpenElective = isOpenElective
                    )
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Publish Semester Grade Entry", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AdminSyllabusManagerTab(
    syllabusList: List<SyllabusEntity>,
    onSave: (SyllabusEntity) -> Unit,
    onDelete: (SyllabusEntity) -> Unit
) {
    var branchCode by remember { mutableStateOf("CSE") }
    var semester by remember { mutableStateOf("4") }
    var subjectCode by remember { mutableStateOf("CS404") }
    var subjectName by remember { mutableStateOf("Computer Networks & Protocols") }
    var credits by remember { mutableStateOf("4") }
    var hoursLtp by remember { mutableStateOf("3-1-0") }
    var isUuElective by remember { mutableStateOf(false) }

    var m1 by remember { mutableStateOf("Module 1: Introduction to OSI and TCP/IP Architecture") }
    var m2 by remember { mutableStateOf("Module 2: Data Link Layer, Error Detection, MAC Sublayer") }
    var m3 by remember { mutableStateOf("Module 3: Network Layer, IP Addressing, Routing Algorithms") }
    var m4 by remember { mutableStateOf("Module 4: Transport Layer, TCP/UDP Congestion Control") }
    var m5 by remember { mutableStateOf("Module 5: Application Layer Protocols: HTTP, DNS, Security") }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Curriculum & Syllabus Manager (Branches & Semesters)",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            BranchId.entries.forEach { b ->
                FilterChip(
                    selected = branchCode == b.code,
                    onClick = { branchCode = b.code },
                    label = { Text(b.shortName) }
                )
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value = semester, onValueChange = { semester = it }, label = { Text("Semester (1-8)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = subjectCode, onValueChange = { subjectCode = it }, label = { Text("Subject Code") }, modifier = Modifier.weight(1f))
        }

        OutlinedTextField(value = subjectName, onValueChange = { subjectName = it }, label = { Text("Subject Name") }, modifier = Modifier.fillMaxWidth())

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value = credits, onValueChange = { credits = it }, label = { Text("Credits") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = hoursLtp, onValueChange = { hoursLtp = it }, label = { Text("L-T-P Hours") }, modifier = Modifier.weight(1f))
        }

        FilterChip(
            selected = isUuElective,
            onClick = { isUuElective = !isUuElective },
            label = { Text("Is U.U. Open Elective") }
        )

        Text(text = "Modules 1 to 5 Syllabus Content:", style = MaterialTheme.typography.labelMedium)
        OutlinedTextField(value = m1, onValueChange = { m1 = it }, label = { Text("Module 1") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = m2, onValueChange = { m2 = it }, label = { Text("Module 2") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = m3, onValueChange = { m3 = it }, label = { Text("Module 3") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = m4, onValueChange = { m4 = it }, label = { Text("Module 4") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = m5, onValueChange = { m5 = it }, label = { Text("Module 5") }, modifier = Modifier.fillMaxWidth())

        Button(
            onClick = {
                onSave(
                    SyllabusEntity(
                        branchId = branchCode,
                        semester = semester.toIntOrNull() ?: 4,
                        subjectCode = subjectCode.trim(),
                        subjectName = subjectName.trim(),
                        credits = credits.toIntOrNull() ?: 4,
                        hoursLtp = hoursLtp.trim(),
                        isOpenElective = isUuElective,
                        module1 = m1.trim(),
                        module2 = m2.trim(),
                        module3 = m3.trim(),
                        module4 = m4.trim(),
                        module5 = m5.trim(),
                        evaluationScheme = "Internal Assessments (UT1-5: 20 marks average), Mid-Sem (20 marks), End-Semester University Exam (60 marks)."
                    )
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Publish / Update Syllabus", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AddStudentDialog(
    onDismiss: () -> Unit,
    onConfirm: (id: String, name: String, dob: String, branch: String, sem: Int, email: String, phone: String, cgpa: Double) -> Unit
) {
    var id by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var branch by remember { mutableStateOf("CSE") }
    var sem by remember { mutableStateOf("4") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var cgpa by remember { mutableStateOf("8.50") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add New Student Record to Firestore", fontWeight = FontWeight.Bold) },
        text = {
            val scroll = rememberScrollState()
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(scroll),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFEFF6FF),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE))
                ) {
                    Text(
                        text = "This record will be written to Cloud Firestore collection 'students' and the local SIS database. The student's initial confidential password will be their Date of Birth (DOB).",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF1E40AF),
                        modifier = Modifier.padding(8.dp)
                    )
                }

                OutlinedTextField(value = id, onValueChange = { id = it }, label = { Text("Roll Number / Student ID (e.g. 22091A3305)") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = dob, onValueChange = { dob = it }, label = { Text("Date of Birth (DD-MM-YYYY)") }, modifier = Modifier.fillMaxWidth())

                Text(text = "Branch:", style = MaterialTheme.typography.labelSmall)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    BranchId.entries.forEach { b ->
                        FilterChip(
                            selected = branch == b.code,
                            onClick = { branch = b.code },
                            label = { Text(b.shortName) }
                        )
                    }
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = sem, onValueChange = { sem = it }, label = { Text("Semester") }, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = cgpa, onValueChange = { cgpa = it }, label = { Text("Initial CGPA") }, modifier = Modifier.weight(1f))
                }

                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email Address") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Mobile Number") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (id.isNotBlank() && name.isNotBlank() && dob.isNotBlank()) {
                        onConfirm(
                            id,
                            name,
                            dob,
                            branch,
                            sem.toIntOrNull() ?: 1,
                            email.ifBlank { "${id.lowercase()}@collegeportal.edu" },
                            phone.ifBlank { "+91 9876543210" },
                            cgpa.toDoubleOrNull() ?: 8.0
                        )
                    }
                }
            ) {
                Text("Save Student to Firestore", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
