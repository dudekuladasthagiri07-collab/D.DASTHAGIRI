package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.CollegeDao
import com.example.data.model.AdminEntity
import com.example.data.model.AttendanceEntity
import com.example.data.model.SemesterResultEntity
import com.example.data.model.StudentEntity
import com.example.data.model.SyllabusEntity
import com.example.data.model.UnitTestResultEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        StudentEntity::class,
        AttendanceEntity::class,
        UnitTestResultEntity::class,
        SemesterResultEntity::class,
        SyllabusEntity::class,
        AdminEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class CollegeDatabase : RoomDatabase() {

    abstract fun collegeDao(): CollegeDao

    companion object {
        @Volatile
        private var INSTANCE: CollegeDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): CollegeDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CollegeDatabase::class.java,
                    "college_portal_database"
                )
                    .addCallback(CollegeDatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class CollegeDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        DatabaseSeeder.seedInitialData(database.collegeDao())
                    }
                }
            }
        }
    }
}
