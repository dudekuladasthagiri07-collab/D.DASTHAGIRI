package com.example.data.repository

import com.example.data.dao.CollegeDao
import com.example.data.model.AdminEntity
import com.example.data.model.AttendanceEntity
import com.example.data.model.SemesterResultEntity
import com.example.data.model.StudentEntity
import com.example.data.model.SyllabusEntity
import com.example.data.model.UnitTestResultEntity
import com.example.security.SecurityUtils
import kotlinx.coroutines.flow.Flow

class CollegeRepository(private val dao: CollegeDao) {

    // Students
    fun getStudent(studentId: String): Flow<StudentEntity?> = dao.getStudentById(studentId)

    suspend fun getStudentDirect(studentId: String): StudentEntity? = dao.getStudentByIdDirect(studentId)

    suspend fun getStudentByEmail(email: String): StudentEntity? = dao.getStudentByEmailDirect(email)

    fun getAllStudents(): Flow<List<StudentEntity>> = dao.getAllStudents()

    fun getStudentsByBranch(branchId: String): Flow<List<StudentEntity>> = dao.getStudentsByBranch(branchId)

    suspend fun createStudent(
        studentId: String,
        name: String,
        dateOfBirth: String,
        branchId: String,
        semester: Int,
        email: String,
        phone: String,
        enrollmentYear: Int,
        cgpa: Double
    ): StudentEntity {
        val salt = SecurityUtils.generateSalt()
        val normalizedDob = SecurityUtils.normalizeDob(dateOfBirth)
        // Temporary initial password is date of birth
        val passwordHash = SecurityUtils.hashPassword(normalizedDob, salt)
        val student = StudentEntity(
            studentId = studentId.trim().uppercase(),
            name = name.trim(),
            dateOfBirth = normalizedDob,
            passwordHash = passwordHash,
            salt = salt,
            isFirstLogin = true,
            branchId = branchId,
            currentSemester = semester,
            email = email.trim(),
            phone = phone.trim(),
            enrollmentYear = enrollmentYear,
            cgpa = cgpa
        )
        dao.insertStudent(student)
        try {
            com.example.data.firebase.DatabaseHelper.saveStudentToFirestore(student)
        } catch (e: Exception) {
            android.util.Log.w("CollegeRepository", "Firestore save note: ${e.message}")
        }
        return student
    }

    suspend fun updateStudent(student: StudentEntity) {
        dao.updateStudent(student)
        try {
            com.example.data.firebase.DatabaseHelper.saveStudentToFirestore(student)
        } catch (e: Exception) {
            android.util.Log.w("CollegeRepository", "Firestore update note: ${e.message}")
        }
    }

    suspend fun updateStudentPassword(studentId: String, newPassword: String) {
        val student = dao.getStudentByIdDirect(studentId) ?: return
        val newSalt = SecurityUtils.generateSalt()
        val newHash = SecurityUtils.hashPassword(newPassword, newSalt)
        val updated = student.copy(
            passwordHash = newHash,
            salt = newSalt,
            isFirstLogin = false
        )
        dao.updateStudent(updated)
        try {
            com.example.data.firebase.DatabaseHelper.saveStudentToFirestore(updated)
        } catch (e: Exception) {
            android.util.Log.w("CollegeRepository", "Firestore password sync note: ${e.message}")
        }
    }

    suspend fun resetStudentPasswordToDob(studentId: String): Boolean {
        val student = dao.getStudentByIdDirect(studentId) ?: return false
        val newSalt = SecurityUtils.generateSalt()
        val newHash = SecurityUtils.hashPassword(student.dateOfBirth, newSalt)
        val updated = student.copy(
            passwordHash = newHash,
            salt = newSalt,
            isFirstLogin = true
        )
        dao.updateStudent(updated)
        try {
            com.example.data.firebase.DatabaseHelper.saveStudentToFirestore(updated)
        } catch (e: Exception) {
            android.util.Log.w("CollegeRepository", "Firestore reset note: ${e.message}")
        }
        return true
    }

    // Attendance
    fun getAttendanceForStudent(studentId: String): Flow<List<AttendanceEntity>> =
        dao.getAttendanceForStudent(studentId)

    suspend fun saveAttendance(attendance: AttendanceEntity) = dao.insertAttendance(attendance)

    suspend fun updateAttendance(attendance: AttendanceEntity) = dao.updateAttendance(attendance)

    suspend fun deleteAttendance(attendance: AttendanceEntity) = dao.deleteAttendance(attendance)

    // Unit Tests
    fun getUnitTestsForStudent(studentId: String): Flow<List<UnitTestResultEntity>> =
        dao.getUnitTestsForStudent(studentId)

    suspend fun saveUnitTest(unitTest: UnitTestResultEntity) = dao.insertUnitTest(unitTest)

    suspend fun updateUnitTest(unitTest: UnitTestResultEntity) = dao.updateUnitTest(unitTest)

    // Semester Results
    fun getSemesterResultsForStudent(studentId: String): Flow<List<SemesterResultEntity>> =
        dao.getSemesterResultsForStudent(studentId)

    fun getSemesterResultsForStudentAndSem(studentId: String, sem: Int): Flow<List<SemesterResultEntity>> =
        dao.getSemesterResultsForStudentAndSem(studentId, sem)

    suspend fun saveSemesterResult(result: SemesterResultEntity) = dao.insertSemesterResult(result)

    suspend fun updateSemesterResult(result: SemesterResultEntity) = dao.updateSemesterResult(result)

    // Syllabus
    fun getSyllabusForBranchAndSem(branchId: String, sem: Int): Flow<List<SyllabusEntity>> =
        dao.getSyllabusForBranchAndSem(branchId, sem)

    fun getAllSyllabus(): Flow<List<SyllabusEntity>> = dao.getAllSyllabus()

    suspend fun saveSyllabus(syllabus: SyllabusEntity) = dao.insertSyllabus(syllabus)

    suspend fun updateSyllabus(syllabus: SyllabusEntity) = dao.updateSyllabus(syllabus)

    suspend fun deleteSyllabus(syllabus: SyllabusEntity) = dao.deleteSyllabus(syllabus)

    // Admin Auth
    suspend fun getAdmin(adminId: String): AdminEntity? = dao.getAdminById(adminId)

    suspend fun getAdminByEmail(email: String): AdminEntity? = dao.getAdminByEmailDirect(email)

    suspend fun ensureAdminExists() {
        val admin = dao.getAdminById("ADMIN001")
        if (admin == null) {
            val adminSalt = SecurityUtils.generateSalt()
            val adminHash = SecurityUtils.hashPassword("admin@portal2026", adminSalt)
            dao.insertAdmin(
                AdminEntity(
                    adminId = "ADMIN001",
                    name = "Dr. S. K. Narayanan (Registrar)",
                    passwordHash = adminHash,
                    salt = adminSalt,
                    email = "admin@collegeportal.edu",
                    role = "ADMIN"
                )
            )
        }
    }
}
