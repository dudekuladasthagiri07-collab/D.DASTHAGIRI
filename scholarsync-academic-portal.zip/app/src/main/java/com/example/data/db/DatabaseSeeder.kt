package com.example.data.db

import com.example.data.dao.CollegeDao
import com.example.data.model.AdminEntity
import com.example.data.model.AttendanceEntity
import com.example.data.model.SemesterResultEntity
import com.example.data.model.StudentEntity
import com.example.data.model.SyllabusEntity
import com.example.data.model.UnitTestResultEntity
import com.example.security.SecurityUtils

object DatabaseSeeder {

    suspend fun seedInitialData(dao: CollegeDao) {
        // 1. Seed Admin
        val adminSalt = SecurityUtils.generateSalt()
        val adminPasswordHash = SecurityUtils.hashPassword("admin@portal2026", adminSalt)
        val defaultAdmin = AdminEntity(
            adminId = "ADMIN001",
            name = "Dr. S. K. Narayanan (Registrar)",
            passwordHash = adminPasswordHash,
            salt = adminSalt,
            email = "admin@collegeportal.edu",
            role = "ADMIN"
        )
        dao.insertAdmin(defaultAdmin)

        // 2. Students for RGMCET (Highlighting Cyber Security student D. Dasthagiri)
        val students = listOf(
            // RGMCET Cyber Security Lead - D. Dasthagiri
            createStudent(
                studentId = "22091A3301",
                name = "D. Dasthagiri",
                dob = "10-06-2004",
                branchId = "CYBER",
                sem = 4,
                email = "dudekuladasthagiri988@gmail.com",
                phone = "+91 91234 56789",
                cgpa = 9.45,
                isFirstLogin = false
            ),
            // CSE
            createStudent(
                studentId = "CSE202401",
                name = "Aarav Sharma",
                dob = "15-08-2004",
                branchId = "CSE",
                sem = 4,
                email = "aarav.cse@college.edu",
                phone = "+91 98765 43210",
                cgpa = 8.82,
                isFirstLogin = false // Already transitioned, can test profile change password
            ),
            // AI/ML
            createStudent(
                studentId = "AIML202402",
                name = "Priya Patel",
                dob = "22-11-2004",
                branchId = "AIML",
                sem = 4,
                email = "priya.aiml@college.edu",
                phone = "+91 98765 43211",
                cgpa = 9.15,
                isFirstLogin = true // Test first-login mandatory password change!
            ),
            // Cyber Security
            createStudent(
                studentId = "CYBER202403",
                name = "Rohan Verma",
                dob = "05-03-2004",
                branchId = "CYBER",
                sem = 4,
                email = "rohan.cyber@college.edu",
                phone = "+91 98765 43212",
                cgpa = 7.42, // Shows attendance warning demo
                isFirstLogin = false
            ),
            // Data Science
            createStudent(
                studentId = "DS202404",
                name = "Ananya Rao",
                dob = "18-09-2004",
                branchId = "DATA_SCIENCE",
                sem = 4,
                email = "ananya.ds@college.edu",
                phone = "+91 98765 43213",
                cgpa = 8.65,
                isFirstLogin = false
            ),
            // ECE
            createStudent(
                studentId = "ECE202405",
                name = "Vikram Singh",
                dob = "10-01-2004",
                branchId = "ECE",
                sem = 4,
                email = "vikram.ece@college.edu",
                phone = "+91 98765 43214",
                cgpa = 8.30,
                isFirstLogin = false
            ),
            // EEE
            createStudent(
                studentId = "EEE202406",
                name = "Sneha Reddy",
                dob = "30-07-2004",
                branchId = "EEE",
                sem = 4,
                email = "sneha.eee@college.edu",
                phone = "+91 98765 43215",
                cgpa = 8.54,
                isFirstLogin = false
            ),
            // Civil
            createStudent(
                studentId = "CIVIL202407",
                name = "Karthik Nair",
                dob = "14-04-2004",
                branchId = "CIVIL",
                sem = 4,
                email = "karthik.civil@college.edu",
                phone = "+91 98765 43216",
                cgpa = 7.95,
                isFirstLogin = false
            ),
            // Mechanical
            createStudent(
                studentId = "MECH202408",
                name = "Aditya Kulkarni",
                dob = "25-12-2004",
                branchId = "MECHANICAL",
                sem = 4,
                email = "aditya.mech@college.edu",
                phone = "+91 98765 43217",
                cgpa = 8.12,
                isFirstLogin = false
            )
        )
        dao.insertStudents(students)

        // 3. Attendance Data
        val attendances = mutableListOf<AttendanceEntity>()
        // RGMCET Cyber Security Lead D. Dasthagiri (Excellent attendance: 92.8%)
        attendances.addAll(listOf(
            AttendanceEntity(studentId = "22091A3301", subjectName = "Cryptography & Network Security", subjectCode = "CY401", totalClasses = 50, attendedClasses = 48, previousMonthPercentage = 94.0, monthlyHistoryCsv = "92.0,94.0,95.0,96.0"),
            AttendanceEntity(studentId = "22091A3301", subjectName = "Ethical Hacking & Penetration Testing", subjectCode = "CY402", totalClasses = 46, attendedClasses = 43, previousMonthPercentage = 92.0, monthlyHistoryCsv = "90.0,91.5,92.0,93.5"),
            AttendanceEntity(studentId = "22091A3301", subjectName = "Cyber Forensics & Incident Response", subjectCode = "CY403", totalClasses = 44, attendedClasses = 41, previousMonthPercentage = 91.0, monthlyHistoryCsv = "90.0,91.0,92.0,93.2"),
            AttendanceEntity(studentId = "22091A3301", subjectName = "Cloud & Virtualization Security", subjectCode = "CY404", totalClasses = 40, attendedClasses = 37, previousMonthPercentage = 90.0, monthlyHistoryCsv = "88.0,90.0,91.0,92.5"),
            AttendanceEntity(studentId = "22091A3301", subjectName = "University Open: Cyber Laws & IPR (U.U.)", subjectCode = "UU405", totalClasses = 32, attendedClasses = 30, previousMonthPercentage = 93.0, monthlyHistoryCsv = "91.0,92.5,93.0,93.8"),
            AttendanceEntity(studentId = "22091A3301", subjectName = "Cyber Security Lab & CTF Practicum", subjectCode = "CY406P", totalClasses = 24, attendedClasses = 24, previousMonthPercentage = 100.0, monthlyHistoryCsv = "98.0,100.0,100.0,100.0")
        ))

        // CSE Aarav Sharma (Good attendance ~87%)
        attendances.addAll(listOf(
            AttendanceEntity(studentId = "CSE202401", subjectName = "Design & Analysis of Algorithms", subjectCode = "CS401", totalClasses = 48, attendedClasses = 43, previousMonthPercentage = 85.0, monthlyHistoryCsv = "82.0,84.5,85.0,89.5"),
            AttendanceEntity(studentId = "CSE202401", subjectName = "Database Management Systems", subjectCode = "CS402", totalClasses = 52, attendedClasses = 47, previousMonthPercentage = 88.0, monthlyHistoryCsv = "85.0,88.0,91.0,90.3"),
            AttendanceEntity(studentId = "CSE202401", subjectName = "Operating Systems Concepts", subjectCode = "CS403", totalClasses = 45, attendedClasses = 38, previousMonthPercentage = 82.5, monthlyHistoryCsv = "80.0,81.0,82.5,84.4"),
            AttendanceEntity(studentId = "CSE202401", subjectName = "Computer Organization & Arch.", subjectCode = "CS404", totalClasses = 42, attendedClasses = 36, previousMonthPercentage = 84.0, monthlyHistoryCsv = "83.0,84.0,85.0,85.7"),
            AttendanceEntity(studentId = "CSE202401", subjectName = "University Open: Universal Human Values (U.U.)", subjectCode = "UU405", totalClasses = 30, attendedClasses = 28, previousMonthPercentage = 90.0, monthlyHistoryCsv = "88.0,90.0,92.0,93.3"),
            AttendanceEntity(studentId = "CSE202401", subjectName = "Algorithms Lab & Practicum", subjectCode = "CS406P", totalClasses = 24, attendedClasses = 22, previousMonthPercentage = 91.5, monthlyHistoryCsv = "90.0,91.0,91.5,91.6")
        ))

        // Cyber Security Rohan Verma (Critical Attendance Shortage: 69.2% - demonstrates shortage warnings!)
        attendances.addAll(listOf(
            AttendanceEntity(studentId = "CYBER202403", subjectName = "Cryptography & Network Security", subjectCode = "CY401", totalClasses = 50, attendedClasses = 34, previousMonthPercentage = 65.0, monthlyHistoryCsv = "62.0,64.0,65.0,68.0"),
            AttendanceEntity(studentId = "CYBER202403", subjectName = "Ethical Hacking & Defense", subjectCode = "CY402", totalClasses = 46, attendedClasses = 32, previousMonthPercentage = 68.0, monthlyHistoryCsv = "66.0,67.5,68.0,69.5"),
            AttendanceEntity(studentId = "CYBER202403", subjectName = "Cyber Forensics & Incident Analysis", subjectCode = "CY403", totalClasses = 44, attendedClasses = 30, previousMonthPercentage = 70.0, monthlyHistoryCsv = "68.0,70.0,69.0,68.1"),
            AttendanceEntity(studentId = "CYBER202403", subjectName = "Cloud Infrastructure Security", subjectCode = "CY404", totalClasses = 40, attendedClasses = 27, previousMonthPercentage = 66.0, monthlyHistoryCsv = "65.0,66.0,67.0,67.5"),
            AttendanceEntity(studentId = "CYBER202403", subjectName = "University Open: Cyber Laws & Ethics (U.U.)", subjectCode = "UU405", totalClasses = 32, attendedClasses = 23, previousMonthPercentage = 71.0, monthlyHistoryCsv = "70.0,71.0,72.0,71.8")
        ))

        // AI/ML Priya Patel (High attendance ~94%)
        attendances.addAll(listOf(
            AttendanceEntity(studentId = "AIML202402", subjectName = "Machine Learning Foundations", subjectCode = "AI401", totalClasses = 48, attendedClasses = 46, previousMonthPercentage = 93.0, monthlyHistoryCsv = "92.0,93.5,95.0,95.8"),
            AttendanceEntity(studentId = "AIML202402", subjectName = "Deep Learning Architectures", subjectCode = "AI402", totalClasses = 50, attendedClasses = 47, previousMonthPercentage = 92.0, monthlyHistoryCsv = "91.0,92.0,93.0,94.0"),
            AttendanceEntity(studentId = "AIML202402", subjectName = "Probability & Applied Statistics", subjectCode = "AI403", totalClasses = 42, attendedClasses = 40, previousMonthPercentage = 94.0, monthlyHistoryCsv = "93.0,94.0,94.5,95.2"),
            AttendanceEntity(studentId = "AIML202402", subjectName = "Natural Language Processing", subjectCode = "AI404", totalClasses = 44, attendedClasses = 41, previousMonthPercentage = 91.0, monthlyHistoryCsv = "90.0,91.0,92.5,93.1"),
            AttendanceEntity(studentId = "AIML202402", subjectName = "University Open: Cognitive Psychology (U.U.)", subjectCode = "UU405", totalClasses = 30, attendedClasses = 29, previousMonthPercentage = 95.0, monthlyHistoryCsv = "94.0,95.0,96.0,96.6")
        ))
        dao.insertAllAttendance(attendances)

        // 4. Unit Test Results (UT 1 to UT 5 separate columns!)
        val unitTests = mutableListOf<UnitTestResultEntity>()
        // RGMCET Cyber Security Lead D. Dasthagiri
        unitTests.addAll(listOf(
            UnitTestResultEntity(studentId = "22091A3301", subjectName = "Cryptography & Network Security", subjectCode = "CY401", maxMarks = 20.0, ut1Marks = 19.5, ut2Marks = 19.0, ut3Marks = 20.0, ut4Marks = 19.5, ut5Marks = 20.0),
            UnitTestResultEntity(studentId = "22091A3301", subjectName = "Ethical Hacking & Penetration Testing", subjectCode = "CY402", maxMarks = 20.0, ut1Marks = 19.0, ut2Marks = 18.5, ut3Marks = 19.5, ut4Marks = 20.0, ut5Marks = 19.5),
            UnitTestResultEntity(studentId = "22091A3301", subjectName = "Cyber Forensics & Incident Response", subjectCode = "CY403", maxMarks = 20.0, ut1Marks = 18.5, ut2Marks = 19.0, ut3Marks = 19.0, ut4Marks = 19.5, ut5Marks = 19.0),
            UnitTestResultEntity(studentId = "22091A3301", subjectName = "Cloud & Virtualization Security", subjectCode = "CY404", maxMarks = 20.0, ut1Marks = 18.0, ut2Marks = 18.5, ut3Marks = 19.0, ut4Marks = 18.5, ut5Marks = 19.5),
            UnitTestResultEntity(studentId = "22091A3301", subjectName = "University Open: Cyber Laws & IPR (U.U.)", subjectCode = "UU405", maxMarks = 20.0, ut1Marks = 20.0, ut2Marks = 19.5, ut3Marks = 20.0, ut4Marks = 20.0, ut5Marks = 20.0),
            UnitTestResultEntity(studentId = "22091A3301", subjectName = "Cyber Security Lab & CTF Practicum", subjectCode = "CY406P", maxMarks = 20.0, ut1Marks = 20.0, ut2Marks = 20.0, ut3Marks = 20.0, ut4Marks = 20.0, ut5Marks = 20.0)
        ))

        // CSE Aarav
        unitTests.addAll(listOf(
            UnitTestResultEntity(studentId = "CSE202401", subjectName = "Design & Analysis of Algorithms", subjectCode = "CS401", maxMarks = 20.0, ut1Marks = 18.5, ut2Marks = 17.0, ut3Marks = 19.0, ut4Marks = 18.0, ut5Marks = 19.5),
            UnitTestResultEntity(studentId = "CSE202401", subjectName = "Database Management Systems", subjectCode = "CS402", maxMarks = 20.0, ut1Marks = 19.0, ut2Marks = 18.5, ut3Marks = 18.0, ut4Marks = 19.5, ut5Marks = 20.0),
            UnitTestResultEntity(studentId = "CSE202401", subjectName = "Operating Systems Concepts", subjectCode = "CS403", maxMarks = 20.0, ut1Marks = 16.5, ut2Marks = 17.5, ut3Marks = 18.0, ut4Marks = 17.0, ut5Marks = 18.5),
            UnitTestResultEntity(studentId = "CSE202401", subjectName = "Computer Organization & Arch.", subjectCode = "CS404", maxMarks = 20.0, ut1Marks = 17.0, ut2Marks = 16.0, ut3Marks = 17.5, ut4Marks = 18.0, ut5Marks = 17.5),
            UnitTestResultEntity(studentId = "CSE202401", subjectName = "University Open: Universal Human Values (U.U.)", subjectCode = "UU405", maxMarks = 20.0, ut1Marks = 19.5, ut2Marks = 19.0, ut3Marks = 20.0, ut4Marks = 19.5, ut5Marks = 20.0),
            UnitTestResultEntity(studentId = "CSE202401", subjectName = "Algorithms Lab & Practicum", subjectCode = "CS406P", maxMarks = 20.0, ut1Marks = 19.0, ut2Marks = 20.0, ut3Marks = 19.5, ut4Marks = 20.0, ut5Marks = 19.5)
        ))

        // AI/ML Priya
        unitTests.addAll(listOf(
            UnitTestResultEntity(studentId = "AIML202402", subjectName = "Machine Learning Foundations", subjectCode = "AI401", maxMarks = 20.0, ut1Marks = 19.5, ut2Marks = 19.0, ut3Marks = 20.0, ut4Marks = 19.5, ut5Marks = 20.0),
            UnitTestResultEntity(studentId = "AIML202402", subjectName = "Deep Learning Architectures", subjectCode = "AI402", maxMarks = 20.0, ut1Marks = 18.5, ut2Marks = 19.0, ut3Marks = 19.5, ut4Marks = 19.0, ut5Marks = 19.5),
            UnitTestResultEntity(studentId = "AIML202402", subjectName = "Probability & Applied Statistics", subjectCode = "AI403", maxMarks = 20.0, ut1Marks = 20.0, ut2Marks = 19.5, ut3Marks = 20.0, ut4Marks = 20.0, ut5Marks = 20.0),
            UnitTestResultEntity(studentId = "AIML202402", subjectName = "Natural Language Processing", subjectCode = "AI404", maxMarks = 20.0, ut1Marks = 18.0, ut2Marks = 18.5, ut3Marks = 19.0, ut4Marks = 18.5, ut5Marks = 19.0),
            UnitTestResultEntity(studentId = "AIML202402", subjectName = "University Open: Cognitive Psychology (U.U.)", subjectCode = "UU405", maxMarks = 20.0, ut1Marks = 19.0, ut2Marks = 19.5, ut3Marks = 19.0, ut4Marks = 20.0, ut5Marks = 19.5)
        ))
        dao.insertAllUnitTests(unitTests)

        // 5. Semester Results (Semester-wise and previous semester results viewing)
        val semesterResults = mutableListOf<SemesterResultEntity>()
        // D. Dasthagiri Semester 4 (SGPA 9.45)
        semesterResults.addAll(listOf(
            SemesterResultEntity(studentId = "22091A3301", semester = 4, subjectName = "Cryptography & Network Security", subjectCode = "CY401", internalMarks = 39, externalMarks = 58, totalMarks = 97, grade = "O", gradePoints = 10, credits = 4, sgpa = 9.45),
            SemesterResultEntity(studentId = "22091A3301", semester = 4, subjectName = "Ethical Hacking & Penetration Testing", subjectCode = "CY402", internalMarks = 38, externalMarks = 55, totalMarks = 93, grade = "O", gradePoints = 10, credits = 4, sgpa = 9.45),
            SemesterResultEntity(studentId = "22091A3301", semester = 4, subjectName = "Cyber Forensics & Incident Response", subjectCode = "CY403", internalMarks = 37, externalMarks = 54, totalMarks = 91, grade = "O", gradePoints = 10, credits = 4, sgpa = 9.45),
            SemesterResultEntity(studentId = "22091A3301", semester = 4, subjectName = "Cloud & Virtualization Security", subjectCode = "CY404", internalMarks = 36, externalMarks = 52, totalMarks = 88, grade = "A+", gradePoints = 9, credits = 3, sgpa = 9.45),
            SemesterResultEntity(studentId = "22091A3301", semester = 4, subjectName = "University Open: Cyber Laws & IPR (U.U.)", subjectCode = "UU405", internalMarks = 39, externalMarks = 57, totalMarks = 96, grade = "O", gradePoints = 10, credits = 3, sgpa = 9.45, isOpenElective = true),
            SemesterResultEntity(studentId = "22091A3301", semester = 4, subjectName = "Cyber Security Lab & CTF Practicum", subjectCode = "CY406P", internalMarks = 40, externalMarks = 59, totalMarks = 99, grade = "O", gradePoints = 10, credits = 2, sgpa = 9.45)
        ))

        // Previous Semester 3 for D. Dasthagiri (SGPA 9.20)
        semesterResults.addAll(listOf(
            SemesterResultEntity(studentId = "22091A3301", semester = 3, subjectName = "Data Structures with C++", subjectCode = "CS301", internalMarks = 38, externalMarks = 54, totalMarks = 92, grade = "O", gradePoints = 10, credits = 4, sgpa = 9.20),
            SemesterResultEntity(studentId = "22091A3301", semester = 3, subjectName = "Information Security Fundamentals", subjectCode = "CY302", internalMarks = 39, externalMarks = 56, totalMarks = 95, grade = "O", gradePoints = 10, credits = 4, sgpa = 9.20),
            SemesterResultEntity(studentId = "22091A3301", semester = 3, subjectName = "Computer Networks Architecture", subjectCode = "CS303", internalMarks = 36, externalMarks = 51, totalMarks = 87, grade = "A+", gradePoints = 9, credits = 4, sgpa = 9.20),
            SemesterResultEntity(studentId = "22091A3301", semester = 3, subjectName = "University Open: Indian Constitution (U.U.)", subjectCode = "UU305", internalMarks = 38, externalMarks = 53, totalMarks = 91, grade = "O", gradePoints = 10, credits = 3, sgpa = 9.20, isOpenElective = true)
        ))

        // Semester 4 (Current) for CSE Aarav
        semesterResults.addAll(listOf(
            SemesterResultEntity(studentId = "CSE202401", semester = 4, subjectName = "Design & Analysis of Algorithms", subjectCode = "CS401", internalMarks = 37, externalMarks = 54, totalMarks = 91, grade = "O", gradePoints = 10, credits = 4, sgpa = 8.92),
            SemesterResultEntity(studentId = "CSE202401", semester = 4, subjectName = "Database Management Systems", subjectCode = "CS402", internalMarks = 38, externalMarks = 52, totalMarks = 90, grade = "O", gradePoints = 10, credits = 4, sgpa = 8.92),
            SemesterResultEntity(studentId = "CSE202401", semester = 4, subjectName = "Operating Systems Concepts", subjectCode = "CS403", internalMarks = 34, externalMarks = 48, totalMarks = 82, grade = "A+", gradePoints = 9, credits = 4, sgpa = 8.92),
            SemesterResultEntity(studentId = "CSE202401", semester = 4, subjectName = "Computer Organization & Arch.", subjectCode = "CS404", internalMarks = 33, externalMarks = 46, totalMarks = 79, grade = "A", gradePoints = 8, credits = 3, sgpa = 8.92),
            SemesterResultEntity(studentId = "CSE202401", semester = 4, subjectName = "University Open: Universal Human Values (U.U.)", subjectCode = "UU405", internalMarks = 39, externalMarks = 56, totalMarks = 95, grade = "O", gradePoints = 10, credits = 3, sgpa = 8.92, isOpenElective = true),
            SemesterResultEntity(studentId = "CSE202401", semester = 4, subjectName = "Algorithms & Database Practicum", subjectCode = "CS406P", internalMarks = 38, externalMarks = 55, totalMarks = 93, grade = "O", gradePoints = 10, credits = 2, sgpa = 8.92)
        ))

        // Previous Semester 3 for Aarav
        semesterResults.addAll(listOf(
            SemesterResultEntity(studentId = "CSE202401", semester = 3, subjectName = "Data Structures & Applications", subjectCode = "CS301", internalMarks = 36, externalMarks = 52, totalMarks = 88, grade = "A+", gradePoints = 9, credits = 4, sgpa = 8.75),
            SemesterResultEntity(studentId = "CSE202401", semester = 3, subjectName = "Discrete Mathematical Structures", subjectCode = "CS302", internalMarks = 35, externalMarks = 50, totalMarks = 85, grade = "A+", gradePoints = 9, credits = 4, sgpa = 8.75),
            SemesterResultEntity(studentId = "CSE202401", semester = 3, subjectName = "Object Oriented Java Programming", subjectCode = "CS303", internalMarks = 38, externalMarks = 54, totalMarks = 92, grade = "O", gradePoints = 10, credits = 4, sgpa = 8.75),
            SemesterResultEntity(studentId = "CSE202401", semester = 3, subjectName = "Digital Logic & Circuit Design", subjectCode = "CS304", internalMarks = 32, externalMarks = 45, totalMarks = 77, grade = "A", gradePoints = 8, credits = 3, sgpa = 8.75),
            SemesterResultEntity(studentId = "CSE202401", semester = 3, subjectName = "Open Elective: Indian Constitution (U.U.)", subjectCode = "UU305", internalMarks = 37, externalMarks = 51, totalMarks = 88, grade = "A+", gradePoints = 9, credits = 3, sgpa = 8.75, isOpenElective = true)
        ))

        // Previous Semester 2 for Aarav
        semesterResults.addAll(listOf(
            SemesterResultEntity(studentId = "CSE202401", semester = 2, subjectName = "Engineering Mathematics II", subjectCode = "MA201", internalMarks = 35, externalMarks = 51, totalMarks = 86, grade = "A+", gradePoints = 9, credits = 4, sgpa = 8.65),
            SemesterResultEntity(studentId = "CSE202401", semester = 2, subjectName = "Engineering Physics & Optics", subjectCode = "PH202", internalMarks = 34, externalMarks = 48, totalMarks = 82, grade = "A+", gradePoints = 9, credits = 4, sgpa = 8.65),
            SemesterResultEntity(studentId = "CSE202401", semester = 2, subjectName = "Basic Electronics Engineering", subjectCode = "EC203", internalMarks = 33, externalMarks = 46, totalMarks = 79, grade = "A", gradePoints = 8, credits = 3, sgpa = 8.65),
            SemesterResultEntity(studentId = "CSE202401", semester = 2, subjectName = "Problem Solving with Python", subjectCode = "CS204", internalMarks = 39, externalMarks = 56, totalMarks = 95, grade = "O", gradePoints = 10, credits = 4, sgpa = 8.65)
        ))
        dao.insertAllSemesterResults(semesterResults)

        // 6. Syllabus for all 8 Branches & Semesters
        val syllabi = listOf(
            // CSE Sem 4
            SyllabusEntity(
                branchId = "CSE",
                semester = 4,
                subjectName = "Design & Analysis of Algorithms",
                subjectCode = "CS401",
                credits = 4,
                hoursLtp = "3-1-0",
                module1 = "Module 1: Introduction to Algorithm Complexity, Asymptotic Notations (Big-O, Omega, Theta), Recurrence Relations and Master Theorem.",
                module2 = "Module 2: Divide & Conquer (MergeSort, QuickSort, Closest Pair) and Greedy Strategies (Fractional Knapsack, Huffman Coding, Dijkstra).",
                module3 = "Module 3: Dynamic Programming Paradigm (0/1 Knapsack, Longest Common Subsequence, Matrix Chain Multiplication, Floyd-Warshall).",
                module4 = "Module 4: Backtracking & Branch and Bound (N-Queens, Graph Coloring, Hamiltonian Cycle, TSP).",
                module5 = "Module 5: NP-Completeness, P vs NP, Approximation Algorithms and Randomized Algorithms (Monte Carlo, Las Vegas)."
            ),
            SyllabusEntity(
                branchId = "CSE",
                semester = 4,
                subjectName = "Database Management Systems",
                subjectCode = "CS402",
                credits = 4,
                hoursLtp = "3-1-0",
                module1 = "Module 1: Database Architecture, Relational Data Model, ER Modeling, Relational Algebra & Calculus.",
                module2 = "Module 2: SQL Advanced Queries, Joins, Triggers, Views, Stored Procedures and Indexing structures.",
                module3 = "Module 3: Relational Database Design, Functional Dependencies, Normal Forms (1NF, 2NF, 3NF, BCNF, 4NF).",
                module4 = "Module 4: Transaction Processing, ACID Properties, Concurrency Control (2PL, Timestamping), Deadlock Handling.",
                module5 = "Module 5: Query Optimization, Crash Recovery (WAL, Checkpoints), Introduction to NoSQL & Distributed Databases."
            ),
            SyllabusEntity(
                branchId = "CSE",
                semester = 4,
                subjectName = "Operating Systems Concepts",
                subjectCode = "CS403",
                credits = 4,
                hoursLtp = "3-1-0",
                module1 = "Module 1: OS Structures, System Calls, Process Lifecycle, Inter-Process Communication (IPC).",
                module2 = "Module 2: CPU Scheduling Algorithms (FCFS, SJF, Round Robin, Multilevel Queues) and Thread Models.",
                module3 = "Module 3: Synchronization Primitives (Mutex, Semaphores, Monitors), Classical Problems (Dining Philosophers, Producer-Consumer).",
                module4 = "Module 4: Memory Management, Paging, Segmentation, Virtual Memory, Page Replacement Algorithms (LRU, FIFO, Clock).",
                module5 = "Module 5: Storage Architecture, File System Implementation, Disk Scheduling (SCAN, C-LOOK) and Protection Domains."
            ),
            SyllabusEntity(
                branchId = "CSE",
                semester = 4,
                subjectName = "Universal Human Values & Professional Ethics (U.U.)",
                subjectCode = "UU405",
                credits = 3,
                hoursLtp = "3-0-0",
                isOpenElective = true,
                module1 = "Module 1: Course Introduction - Need, Basic Guidelines, Content and Process for Value Education.",
                module2 = "Module 2: Understanding Harmony in the Human Being - Harmony in Myself.",
                module3 = "Module 3: Understanding Harmony in the Family and Society - Harmony in Human-Human Relationship.",
                module4 = "Module 4: Understanding Harmony in the Nature and Existence - Whole existence as Co-existence.",
                module5 = "Module 5: Implications of the Holistic Understanding of Harmony on Professional Ethics."
            ),
            // AI/ML Sem 4
            SyllabusEntity(
                branchId = "AIML",
                semester = 4,
                subjectName = "Machine Learning Foundations",
                subjectCode = "AI401",
                credits = 4,
                hoursLtp = "3-1-0",
                module1 = "Module 1: Introduction to Machine Learning, Supervised vs Unsupervised, Bias-Variance Tradeoff, Cross-Validation.",
                module2 = "Module 2: Linear Regression, Logistic Regression, Regularization (L1 Lasso, L2 Ridge), Gradient Descent variants.",
                module3 = "Module 3: Support Vector Machines (SVM), Kernel Trick, Decision Trees (ID3, CART), Ensemble Methods (Random Forest, XGBoost).",
                module4 = "Module 4: Unsupervised Learning, K-Means Clustering, Hierarchical Clustering, Principal Component Analysis (PCA).",
                module5 = "Module 5: Evaluation Metrics (ROC-AUC, Precision-Recall, F1-score), Hyperparameter Tuning and Model Deployment."
            ),
            SyllabusEntity(
                branchId = "AIML",
                semester = 4,
                subjectName = "Deep Learning Architectures",
                subjectCode = "AI402",
                credits = 4,
                hoursLtp = "3-1-0",
                module1 = "Module 1: Perceptrons, Multi-Layer Perceptrons, Backpropagation, Activation Functions (ReLU, GELU, Softmax).",
                module2 = "Module 2: Convolutional Neural Networks (CNNs), Pooling, LeNet, AlexNet, VGG, ResNet Architectures.",
                module3 = "Module 3: Recurrent Neural Networks (RNNs), Vanishing Gradient, Long Short-Term Memory (LSTM), GRU.",
                module4 = "Module 4: Attention Mechanisms, Transformer Architecture, Self-Attention, Multi-Head Attention.",
                module5 = "Module 5: Generative Adversarial Networks (GANs), Autoencoders, Diffusion Models and Fine-Tuning LLMs."
            ),
            // Cyber Security Sem 4
            SyllabusEntity(
                branchId = "CYBER",
                semester = 4,
                subjectName = "Cryptography & Network Security",
                subjectCode = "CY401",
                credits = 4,
                hoursLtp = "3-1-0",
                module1 = "Module 1: Classical Cryptography, Shannon's Secrecy, Block Ciphers, DES, AES Encryption Standards.",
                module2 = "Module 2: Public Key Cryptography, RSA, Diffie-Hellman Key Exchange, Elliptic Curve Cryptography (ECC).",
                module3 = "Module 3: Cryptographic Hash Functions (SHA-2, SHA-3), HMAC, Digital Signatures, PKI Infrastructure.",
                module4 = "Module 4: Transport Layer Security (TLS 1.3), IPsec, Wireless LAN Security, VPN Architecture.",
                module5 = "Module 5: Intrusion Detection Systems (IDS/IPS), Firewalls, Zero-Trust Architecture, DDoS Mitigation."
            ),
            // Data Science Sem 4
            SyllabusEntity(
                branchId = "DATA_SCIENCE",
                semester = 4,
                subjectName = "Big Data Engineering & Spark",
                subjectCode = "DS401",
                credits = 4,
                hoursLtp = "3-1-0",
                module1 = "Module 1: Big Data Ecosystem, HDFS Architecture, MapReduce Programming Model.",
                module2 = "Module 2: Apache Spark Core, Resilient Distributed Datasets (RDDs), Spark SQL and DataFrames.",
                module3 = "Module 3: Real-Time Stream Processing with Apache Kafka and Spark Streaming.",
                module4 = "Module 4: Distributed NoSQL Data Stores (Cassandra, MongoDB, HBase) and Vector Databases.",
                module5 = "Module 5: Data Pipelines, Orchestration with Airflow, Cloud Data Warehousing (BigQuery, Snowflake)."
            ),
            // ECE Sem 4
            SyllabusEntity(
                branchId = "ECE",
                semester = 4,
                subjectName = "Signals & Systems",
                subjectCode = "EC401",
                credits = 4,
                hoursLtp = "3-1-0",
                module1 = "Module 1: Continuous-Time and Discrete-Time Signals, Linear Time-Invariant (LTI) Systems, Convolution Integral.",
                module2 = "Module 2: Fourier Series Analysis, Continuous-Time Fourier Transform (CTFT), Frequency Response.",
                module3 = "Module 3: Laplace Transform, Region of Convergence (ROC), Inverse Laplace, System Transfer Functions.",
                module4 = "Module 4: Discrete-Time Fourier Transform (DTFT), Sampling Theorem, Nyquist Rate, Aliasing.",
                module5 = "Module 5: Z-Transform Analysis, Stability Criteria, Digital Filter Specifications (IIR, FIR)."
            ),
            // EEE Sem 4
            SyllabusEntity(
                branchId = "EEE",
                semester = 4,
                subjectName = "Power Electronics & Drives",
                subjectCode = "EE401",
                credits = 4,
                hoursLtp = "3-1-0",
                module1 = "Module 1: Power Semiconductor Devices (SCR, MOSFET, IGBT), V-I Characteristics, Gate Triggering.",
                module2 = "Module 2: Controlled Rectifiers, Single-Phase & Three-Phase Converters, Dual Converters.",
                module3 = "Module 3: DC-DC Converters (Buck, Boost, Buck-Boost), PWM Control Techniques.",
                module4 = "Module 4: Inverters (Voltage Source & Current Source), Multilevel Inverters, Harmonic Reduction.",
                module5 = "Module 5: Speed Control of Induction & BLDC Motors, Industrial Drive Applications."
            ),
            // Civil Sem 4
            SyllabusEntity(
                branchId = "CIVIL",
                semester = 4,
                subjectName = "Structural Analysis I",
                subjectCode = "CE401",
                credits = 4,
                hoursLtp = "3-1-0",
                module1 = "Module 1: Determinate and Indeterminate Structures, Degree of Static and Kinematic Indeterminacy.",
                module2 = "Module 2: Deflection of Beams and Trusses, Energy Methods, Castigliano's Theorems.",
                module3 = "Module 3: Slope Deflection Method for Continuous Beams and Rigid Portal Frames.",
                module4 = "Module 4: Moment Distribution Method (Hardy Cross), Sway and Non-Sway Frame Analysis.",
                module5 = "Module 5: Moving Loads, Influence Line Diagrams for Statically Determinate Beams and Trusses."
            ),
            // Mechanical Sem 4
            SyllabusEntity(
                branchId = "MECHANICAL",
                semester = 4,
                subjectName = "Applied Thermodynamics & Heat Transfer",
                subjectCode = "ME401",
                credits = 4,
                hoursLtp = "3-1-0",
                module1 = "Module 1: First and Second Laws Applied to Flow Systems, Availability, Irreversibility and Exergy Analysis.",
                module2 = "Module 2: Gas Power Cycles (Otto, Diesel, Dual, Brayton), Mean Effective Pressure, Jet Propulsion.",
                module3 = "Module 3: Vapour Power Cycles (Rankine Cycle), Reheat, Regeneration, Binary Vapour Cycles.",
                module4 = "Module 4: Conduction & Convection Heat Transfer, Fourier's Law, Newton's Law of Cooling, Boundary Layers.",
                module5 = "Module 5: Radiation Heat Transfer, Blackbody Laws, Shape Factors, Heat Exchanger Design (LMTD, NTU)."
            )
        )
        dao.insertAllSyllabus(syllabi)

        // 7. Mirror to Cloud Firestore if Firestore is available
        try {
            if (com.example.data.firebase.DatabaseHelper.isFirestoreAvailable) {
                com.example.data.firebase.DatabaseHelper.saveAdminToFirestore(defaultAdmin)
                students.forEach { com.example.data.firebase.DatabaseHelper.saveStudentToFirestore(it) }
                com.example.data.firebase.DatabaseHelper.syncAttendanceList(attendances)
                com.example.data.firebase.DatabaseHelper.syncUnitTestList(unitTests)
                com.example.data.firebase.DatabaseHelper.syncSemesterResultList(semesterResults)
                com.example.data.firebase.DatabaseHelper.syncSyllabusList(syllabi)
            }
        } catch (e: Exception) {
            android.util.Log.w("DatabaseSeeder", "Firestore mirror sync: ${e.message}")
        }
    }

    private fun createStudent(
        studentId: String,
        name: String,
        dob: String,
        branchId: String,
        sem: Int,
        email: String,
        phone: String,
        cgpa: Double,
        isFirstLogin: Boolean
    ): StudentEntity {
        val salt = SecurityUtils.generateSalt()
        // Initial password is date of birth (e.g. "15-08-2004")
        val passwordHash = SecurityUtils.hashPassword(dob, salt)
        return StudentEntity(
            studentId = studentId,
            name = name,
            dateOfBirth = dob,
            passwordHash = passwordHash,
            salt = salt,
            isFirstLogin = isFirstLogin,
            branchId = branchId,
            currentSemester = sem,
            email = email,
            phone = phone,
            enrollmentYear = 2024,
            cgpa = cgpa
        )
    }
}
