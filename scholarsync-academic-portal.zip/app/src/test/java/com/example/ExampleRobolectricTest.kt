package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.AttendanceEntity
import com.example.data.model.BranchId
import com.example.data.model.UnitTestResultEntity
import com.example.security.SecurityUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("RGMCET Portal", appName)
    }

    @Test
    fun `security utils correctly verifies temporary DOB and hashed password`() {
        val dob = "15-08-2004"
        val salt = SecurityUtils.generateSalt()
        val hash = SecurityUtils.hashPassword(dob, salt)

        // Verifying correct DOB
        assertTrue(SecurityUtils.verifyPassword("15-08-2004", hash, salt))
        assertTrue(SecurityUtils.verifyPassword("15/08/2004", hash, salt))

        // Incorrect password fails
        assertFalse(SecurityUtils.verifyPassword("wrongPassword", hash, salt))
    }

    @Test
    fun `attendance percentage and shortage detection works accurately`() {
        val normal = AttendanceEntity(
            studentId = "CSE202401",
            subjectCode = "CS401",
            subjectName = "Database Systems",
            totalClasses = 50,
            attendedClasses = 45,
            previousMonthPercentage = 88.0
        )
        assertEquals(90.0, normal.attendancePercentage, 0.01)
        assertEquals(5, normal.absentClasses)
        assertFalse(normal.isShortage)

        val shortage = AttendanceEntity(
            studentId = "CYBER202403",
            subjectCode = "CY401",
            subjectName = "Network Security",
            totalClasses = 50,
            attendedClasses = 34,
            previousMonthPercentage = 68.0
        )
        assertEquals(68.0, shortage.attendancePercentage, 0.01)
        assertEquals(16, shortage.absentClasses)
        assertTrue(shortage.isShortage)
    }

    @Test
    fun `unit test entity calculates total marks, average and percentage across tests 1 to 5`() {
        val ut = UnitTestResultEntity(
            studentId = "CSE202401",
            subjectCode = "CS401",
            subjectName = "Database Systems",
            maxMarks = 20.0,
            ut1Marks = 18.0,
            ut2Marks = 17.5,
            ut3Marks = 19.0,
            ut4Marks = 16.5,
            ut5Marks = 19.0
        )
        assertEquals(90.0, ut.totalMarks, 0.01)
        assertEquals(18.0, ut.averageMarks, 0.01)
        assertEquals(90.0, ut.percentage, 0.01)
        assertEquals(100.0, ut.maxTotalMarks, 0.01)
    }

    @Test
    fun `all 8 engineering branches resolve correctly`() {
        val expectedCodes = listOf("CSE", "AIML", "CYBER", "DS", "ECE", "EEE", "CIVIL", "MECH")
        assertEquals(8, BranchId.entries.size)
        expectedCodes.forEach { code ->
            val branch = BranchId.fromCode(code)
            assertTrue(branch.shortName.isNotEmpty())
            assertTrue(branch.fullName.isNotEmpty())
        }
    }

    @Test
    fun `database helper checks roles accurately for admin and student D Dasthagiri`() = kotlinx.coroutines.runBlocking {
        val adminRole = com.example.data.firebase.DatabaseHelper.checkUserRole("admin@rgmcet.edu.in")
        assertEquals("ADMIN", adminRole)

        val studentRole = com.example.data.firebase.DatabaseHelper.checkUserRole("dudekuladasthagiri988@gmail.com")
        assertEquals("STUDENT", studentRole)

        val rollRole = com.example.data.firebase.DatabaseHelper.checkUserRole("22091A3301")
        assertEquals("STUDENT", rollRole)
    }

    @Test
    fun `student password reset restores DOB password and flags first login`() {
        val dob = "10-06-2004"
        val normalizedDob = SecurityUtils.normalizeDob(dob)
        val salt = SecurityUtils.generateSalt()
        val hash = SecurityUtils.hashPassword(normalizedDob, salt)

        var student = com.example.data.model.StudentEntity(
            studentId = "22091A3305",
            name = "K. Sai Kumar",
            dateOfBirth = normalizedDob,
            passwordHash = hash,
            salt = salt,
            isFirstLogin = true,
            branchId = "CYBER",
            currentSemester = 4,
            email = "saikumar@rgmcet.edu.in",
            phone = "+91 9876543210",
            enrollmentYear = 2022,
            cgpa = 8.75
        )

        // Initial state: first login is true, verified by DOB
        assertTrue(student.isFirstLogin)
        assertTrue(SecurityUtils.verifyPassword(dob, student.passwordHash, student.salt))

        // Student changes password
        val newPass = "CyberSec@2026"
        val newSalt = SecurityUtils.generateSalt()
        val newHash = SecurityUtils.hashPassword(newPass, newSalt)
        student = student.copy(passwordHash = newHash, salt = newSalt, isFirstLogin = false)

        assertFalse(student.isFirstLogin)
        assertTrue(SecurityUtils.verifyPassword(newPass, student.passwordHash, student.salt))
        assertFalse(SecurityUtils.verifyPassword(dob, student.passwordHash, student.salt))

        // Admin resets password back to DOB
        val resetSalt = SecurityUtils.generateSalt()
        val resetHash = SecurityUtils.hashPassword(student.dateOfBirth, resetSalt)
        student = student.copy(passwordHash = resetHash, salt = resetSalt, isFirstLogin = true)

        assertTrue(student.isFirstLogin)
        assertTrue(SecurityUtils.verifyPassword(dob, student.passwordHash, student.salt))
    }

    @Test
    fun `isLowAttendance utility function compares against 75 percent threshold correctly`() {
        // Below 75% requirement
        assertTrue(com.example.ui.screens.isLowAttendance(74.9))
        assertTrue(com.example.ui.screens.isLowAttendance(68.0))
        assertTrue(com.example.ui.screens.isLowAttendance(0.0))

        // Exactly at or above 75% requirement
        assertFalse(com.example.ui.screens.isLowAttendance(75.0))
        assertFalse(com.example.ui.screens.isLowAttendance(85.5))
        assertFalse(com.example.ui.screens.isLowAttendance(100.0))

        // Custom threshold
        assertTrue(com.example.ui.screens.isLowAttendance(79.0, threshold = 80.0))
        assertFalse(com.example.ui.screens.isLowAttendance(80.0, threshold = 80.0))
    }

    @Test
    fun `evaluateAttendanceThreshold calculates deficit and required recovery classes`() {
        // Case 1: Attendance at 68% (34 attended out of 50 classes)
        val result = com.example.ui.screens.evaluateAttendanceThreshold(
            percentage = 68.0,
            totalClasses = 50,
            attendedClasses = 34,
            threshold = 75.0
        )
        assertTrue(result.isBelowRequirement)
        assertEquals(7.0, result.deficit, 0.01)
        assertTrue(result.consecutiveClassesNeeded > 0)
        // Verify formula: attending consecutiveClassesNeeded classes makes attendance >= 75%
        val newTotal = 50 + result.consecutiveClassesNeeded
        val newAttended = 34 + result.consecutiveClassesNeeded
        val newPercentage = (newAttended.toDouble() / newTotal) * 100.0
        assertTrue(newPercentage >= 75.0)

        // Case 2: Attendance at 90% (45 attended out of 50 classes)
        val normalResult = com.example.ui.screens.evaluateAttendanceThreshold(
            percentage = 90.0,
            totalClasses = 50,
            attendedClasses = 45,
            threshold = 75.0
        )
        assertFalse(normalResult.isBelowRequirement)
        assertEquals(0.0, normalResult.deficit, 0.01)
        assertEquals(0, normalResult.consecutiveClassesNeeded)
    }

    @Test
    fun `syllabus entity holds complete module specifications and credits`() {
        val syllabus = com.example.data.model.SyllabusEntity(
            branchId = "CYBER",
            semester = 4,
            subjectCode = "CY401",
            subjectName = "Cryptography & Network Security",
            credits = 4,
            hoursLtp = "3-1-0",
            isOpenElective = false,
            module1 = "Module 1: Classical Cryptography, DES, AES",
            module2 = "Module 2: Public Key Cryptography, RSA, ECC",
            module3 = "Module 3: Cryptographic Hash Functions (SHA-2, SHA-3)",
            module4 = "Module 4: Transport Layer Security (TLS 1.3), IPsec",
            module5 = "Module 5: Intrusion Detection Systems (IDS/IPS), Zero-Trust",
            evaluationScheme = "Internal Assessments (UT1-5: 20 marks), Mid-Sem (20 marks), End-Semester Exam (60 marks)."
        )

        assertEquals("CYBER", syllabus.branchId)
        assertEquals(4, syllabus.semester)
        assertEquals("CY401", syllabus.subjectCode)
        assertEquals(4, syllabus.credits)
        assertFalse(syllabus.isOpenElective)
        assertTrue(syllabus.module1.isNotEmpty())
        assertTrue(syllabus.module5.isNotEmpty())
    }

    @Test
    fun `branchColorScheme dynamic mapping gives tech-focused deep blue for cyber and slate for civil`() {
        val cyberLightScheme = com.example.ui.theme.getBranchColorScheme(BranchId.CYBER, darkTheme = false)
        val civilLightScheme = com.example.ui.theme.getBranchColorScheme(BranchId.CIVIL, darkTheme = false)

        // Cyber Security gets tech-focused deep blue theme
        assertEquals(androidx.compose.ui.graphics.Color(0xFF0F3E75), cyberLightScheme.primary)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF0284C7), cyberLightScheme.secondary)

        // Civil gets slate theme
        assertEquals(androidx.compose.ui.graphics.Color(0xFF475569), civilLightScheme.primary)
        assertEquals(androidx.compose.ui.graphics.Color(0xFF64748B), civilLightScheme.secondary)

        // Verifying mapping entries
        assertTrue(com.example.ui.theme.BranchLightColorSchemes.containsKey(BranchId.CYBER))
        assertTrue(com.example.ui.theme.BranchLightColorSchemes.containsKey(BranchId.CIVIL))
        assertTrue(com.example.ui.theme.BranchLightColorSchemes.containsKey(BranchId.CSE))
        assertTrue(com.example.ui.theme.BranchLightColorSchemes.containsKey(BranchId.AIML))
        assertTrue(com.example.ui.theme.BranchLightColorSchemes.containsKey(BranchId.DATA_SCIENCE))
        assertTrue(com.example.ui.theme.BranchLightColorSchemes.containsKey(BranchId.ECE))
        assertTrue(com.example.ui.theme.BranchLightColorSchemes.containsKey(BranchId.EEE))
        assertTrue(com.example.ui.theme.BranchLightColorSchemes.containsKey(BranchId.MECHANICAL))
    }

    @Test
    fun `unit test benchmark provider accurately compares marks against class average`() {
        val sampleTests = listOf(
            UnitTestResultEntity(
                studentId = "22091A3301",
                subjectName = "Cryptography & Network Security",
                subjectCode = "CY401",
                maxMarks = 20.0,
                ut1Marks = 19.5,
                ut2Marks = 18.0,
                ut3Marks = 19.0,
                ut4Marks = 20.0,
                ut5Marks = 19.5
            ),
            UnitTestResultEntity(
                studentId = "22091A3301",
                subjectName = "Cloud & Virtualization Security",
                subjectCode = "CY404",
                maxMarks = 20.0,
                ut1Marks = 12.0,
                ut2Marks = 14.0,
                ut3Marks = 15.0,
                ut4Marks = 16.0,
                ut5Marks = 17.0
            )
        )

        val ut1Comparisons = com.example.ui.screens.UnitTestBenchmarkProvider.buildComparisonList(sampleTests, 1)
        assertEquals(2, ut1Comparisons.size)

        val cy401 = ut1Comparisons.first { it.subjectCode == "CY401" }
        assertEquals(19.5, cy401.studentScore, 0.01)
        assertTrue(cy401.classAverage in 12.0..18.0)
        assertTrue(cy401.difference > 0)
        assertTrue(cy401.isAboveAverage)

        val cy404 = ut1Comparisons.first { it.subjectCode == "CY404" }
        assertEquals(12.0, cy404.studentScore, 0.01)
        assertTrue(cy404.difference < 0)
        assertFalse(cy404.isAboveAverage)
    }
}
