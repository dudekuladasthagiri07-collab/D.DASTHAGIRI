package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Architecture
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class BranchId(
    val code: String,
    val fullName: String,
    val shortName: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val surfaceGradientStart: Color,
    val surfaceGradientEnd: Color,
    val icon: ImageVector,
    val description: String
) {
    CSE(
        code = "CSE",
        fullName = "Computer Science & Engineering",
        shortName = "CSE",
        primaryColor = Color(0xFF1E40AF), // Deep Tech Blue
        secondaryColor = Color(0xFF0284C7),
        surfaceGradientStart = Color(0xFF1E3A8A),
        surfaceGradientEnd = Color(0xFF0284C7),
        icon = Icons.Default.Computer,
        description = "Algorithms, Software Architecture, Full-Stack Systems & Cloud Computing"
    ),
    AIML(
        code = "AIML",
        fullName = "Artificial Intelligence & Machine Learning",
        shortName = "AI/ML",
        primaryColor = Color(0xFF6D28D9), // Deep Neural Violet
        secondaryColor = Color(0xFFA855F7),
        surfaceGradientStart = Color(0xFF5B21B6),
        surfaceGradientEnd = Color(0xFF9333EA),
        icon = Icons.Default.AutoAwesome,
        description = "Deep Learning, Neural Networks, Computer Vision & Generative Intelligence"
    ),
    CYBER(
        code = "CYBER",
        fullName = "Cyber Security",
        shortName = "Cyber Security",
        primaryColor = Color(0xFF0F3E75), // Tech-focused Deep Blue
        secondaryColor = Color(0xFF0284C7), // Tech Sky/Cyan Blue
        surfaceGradientStart = Color(0xFF0A2540),
        surfaceGradientEnd = Color(0xFF0F3E75),
        icon = Icons.Default.Security,
        description = "Cryptographic Systems, Ethical Hacking, Network Defense & Forensics"
    ),
    DATA_SCIENCE(
        code = "DATA_SCIENCE",
        fullName = "Data Science",
        shortName = "Data Science",
        primaryColor = Color(0xFF0369A1), // Deep Ocean Blue
        secondaryColor = Color(0xFF0EA5E9),
        surfaceGradientStart = Color(0xFF075985),
        surfaceGradientEnd = Color(0xFF0284C7),
        icon = Icons.Default.Analytics,
        description = "Big Data Analytics, Statistical Inference, Predictive Modeling & BI"
    ),
    ECE(
        code = "ECE",
        fullName = "Electronics & Communication Engineering",
        shortName = "ECE",
        primaryColor = Color(0xFF991B1B), // Signal Crimson
        secondaryColor = Color(0xFFEF4444),
        surfaceGradientStart = Color(0xFF7F1D1D),
        surfaceGradientEnd = Color(0xFFDC2626),
        icon = Icons.Default.Router,
        description = "VLSI Design, Signal Processing, Embedded Systems & Wireless Telecom"
    ),
    EEE(
        code = "EEE",
        fullName = "Electrical & Electronics Engineering",
        shortName = "EEE",
        primaryColor = Color(0xFFB45309), // Electric Amber
        secondaryColor = Color(0xFFF59E0B),
        surfaceGradientStart = Color(0xFF92400E),
        surfaceGradientEnd = Color(0xFFD97706),
        icon = Icons.Default.Bolt,
        description = "Power Systems, Smart Grids, Electric Drives & Renewable Energy"
    ),
    CIVIL(
        code = "CIVIL",
        fullName = "Civil Engineering",
        shortName = "Civil",
        primaryColor = Color(0xFF475569), // Slate theme
        secondaryColor = Color(0xFF64748B), // Medium Slate
        surfaceGradientStart = Color(0xFF334155),
        surfaceGradientEnd = Color(0xFF475569),
        icon = Icons.Default.Architecture,
        description = "Structural Design, Geotechnical Systems, Transportation & Smart Cities"
    ),
    MECHANICAL(
        code = "MECHANICAL",
        fullName = "Mechanical Engineering",
        shortName = "Mechanical",
        primaryColor = Color(0xFF334155), // Precision Steel Slate
        secondaryColor = Color(0xFF64748B),
        surfaceGradientStart = Color(0xFF1E293B),
        surfaceGradientEnd = Color(0xFF475569),
        icon = Icons.Default.Build,
        description = "Thermodynamics, Robotics, CAD/CAM, Mechatronics & Automotive"
    );

    companion object {
        fun fromCode(code: String): BranchId {
            return entries.find { 
                it.code.equals(code, ignoreCase = true) || 
                it.shortName.equals(code, ignoreCase = true) 
            } ?: CSE
        }
    }
}
