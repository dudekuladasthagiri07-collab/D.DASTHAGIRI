package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AdminEntity
import com.example.data.model.AttendanceEntity
import com.example.data.model.SemesterResultEntity
import com.example.data.model.StudentEntity
import com.example.data.model.SyllabusEntity
import com.example.data.model.UnitTestResultEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CollegeDao {

    // --- Students ---
    @Query("SELECT * FROM students WHERE studentId = :studentId LIMIT 1")
    fun getStudentById(studentId: String): Flow<StudentEntity?>

    @Query("SELECT * FROM students WHERE studentId = :studentId LIMIT 1")
    suspend fun getStudentByIdDirect(studentId: String): StudentEntity?

    @Query("SELECT * FROM students WHERE LOWER(email) = LOWER(:email) LIMIT 1")
    suspend fun getStudentByEmailDirect(email: String): StudentEntity?

    @Query("SELECT * FROM students ORDER BY studentId ASC")
    fun getAllStudents(): Flow<List<StudentEntity>>

    @Query("SELECT * FROM students WHERE branchId = :branchId ORDER BY studentId ASC")
    fun getStudentsByBranch(branchId: String): Flow<List<StudentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudent(student: StudentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudents(students: List<StudentEntity>)

    @Update
    suspend fun updateStudent(student: StudentEntity)

    @Delete
    suspend fun deleteStudent(student: StudentEntity)

    // --- Attendance ---
    @Query("SELECT * FROM attendance WHERE studentId = :studentId ORDER BY subjectCode ASC")
    fun getAttendanceForStudent(studentId: String): Flow<List<AttendanceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttendance(attendance: AttendanceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllAttendance(attendances: List<AttendanceEntity>)

    @Update
    suspend fun updateAttendance(attendance: AttendanceEntity)

    @Delete
    suspend fun deleteAttendance(attendance: AttendanceEntity)

    // --- Unit Tests ---
    @Query("SELECT * FROM unit_tests WHERE studentId = :studentId ORDER BY subjectCode ASC")
    fun getUnitTestsForStudent(studentId: String): Flow<List<UnitTestResultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUnitTest(unitTest: UnitTestResultEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllUnitTests(unitTests: List<UnitTestResultEntity>)

    @Update
    suspend fun updateUnitTest(unitTest: UnitTestResultEntity)

    // --- Semester Results ---
    @Query("SELECT * FROM semester_results WHERE studentId = :studentId ORDER BY semester ASC, subjectCode ASC")
    fun getSemesterResultsForStudent(studentId: String): Flow<List<SemesterResultEntity>>

    @Query("SELECT * FROM semester_results WHERE studentId = :studentId AND semester = :semester ORDER BY subjectCode ASC")
    fun getSemesterResultsForStudentAndSem(studentId: String, semester: Int): Flow<List<SemesterResultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSemesterResult(result: SemesterResultEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSemesterResults(results: List<SemesterResultEntity>)

    @Update
    suspend fun updateSemesterResult(result: SemesterResultEntity)

    // --- Syllabus ---
    @Query("SELECT * FROM syllabus WHERE branchId = :branchId AND semester = :semester ORDER BY subjectCode ASC")
    fun getSyllabusForBranchAndSem(branchId: String, semester: Int): Flow<List<SyllabusEntity>>

    @Query("SELECT * FROM syllabus ORDER BY branchId ASC, semester ASC, subjectCode ASC")
    fun getAllSyllabus(): Flow<List<SyllabusEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSyllabus(syllabus: SyllabusEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSyllabus(syllabi: List<SyllabusEntity>)

    @Update
    suspend fun updateSyllabus(syllabus: SyllabusEntity)

    @Delete
    suspend fun deleteSyllabus(syllabus: SyllabusEntity)

    // --- Admin ---
    @Query("SELECT * FROM admins WHERE adminId = :adminId LIMIT 1")
    suspend fun getAdminById(adminId: String): AdminEntity?

    @Query("SELECT * FROM admins WHERE LOWER(email) = LOWER(:email) LIMIT 1")
    suspend fun getAdminByEmailDirect(email: String): AdminEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdmin(admin: AdminEntity)

    @Query("SELECT * FROM admins")
    fun getAllAdmins(): Flow<List<AdminEntity>>
}
