package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BranchId
import com.example.data.model.StudentEntity
import com.example.ui.components.BranchBadge
import com.example.ui.components.ChangePasswordDialog
import com.example.ui.viewmodel.CollegeViewModel

/**
 * UserProfileScreen Composable
 * Displays the student's personal details, branch, and semester fetched from Firestore,
 * and includes a 'Change Password' button that triggers an authentication update.
 */
@Composable
fun UserProfileScreen(
    student: StudentEntity,
    viewModel: CollegeViewModel,
    modifier: Modifier = Modifier
) {
    var firestoreStudent by remember { mutableStateOf<StudentEntity?>(null) }
    var isLoadingFirestore by remember { mutableStateOf(true) }
    var isFirestoreSynced by remember { mutableStateOf(false) }

    // Fetch student profile details from Firestore on launch
    LaunchedEffect(student.studentId) {
        isLoadingFirestore = true
        viewModel.fetchStudentProfileFromFirestore(student.studentId) { result ->
            if (result != null) {
                firestoreStudent = result
                isFirestoreSynced = true
            }
            isLoadingFirestore = false
        }
    }

    val currentStudent = firestoreStudent ?: student
    val branch = BranchId.fromCode(currentStudent.branchId)
    val attendanceList by viewModel.attendanceList.collectAsState()

    val totalAttended = attendanceList.sumOf { it.attendedClasses }
    val totalClasses = attendanceList.sumOf { it.totalClasses }
    val overallAttendance = if (totalClasses > 0) (totalAttended.toDouble() / totalClasses) * 100.0 else 0.0

    var showPasswordDialog by remember { mutableStateOf(false) }
    var passwordChangeMessage by remember { mutableStateOf<String?>(null) }
    var passwordChangeSuccess by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    if (showPasswordDialog) {
        ChangePasswordDialog(
            onDismiss = { showPasswordDialog = false },
            onSubmit = { oldPass, newPass ->
                viewModel.changePasswordWithAuthUpdate(oldPass, newPass) { success, err ->
                    if (success) {
                        passwordChangeSuccess = true
                        passwordChangeMessage = "Password successfully updated! Authentication credentials and Firestore records are now refreshed."
                        showPasswordDialog = false
                    } else {
                        passwordChangeSuccess = false
                        passwordChangeMessage = err ?: "Failed to update password."
                    }
                }
            },
            errorMessage = if (!passwordChangeSuccess) passwordChangeMessage else null
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Firestore Sync Status Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isFirestoreSynced) Color(0xFFF0FDF4) else Color(0xFFF8FAFC)
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isFirestoreSynced) Color(0xFFBBF7D0) else Color(0xFFE2E8F0)
            )
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (isLoadingFirestore) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = Color(0xFF0284C7)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.CloudDone,
                            contentDescription = null,
                            tint = if (isFirestoreSynced) Color(0xFF16A34A) else Color(0xFF64748B),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = if (isLoadingFirestore) "Fetching from Cloud Firestore..."
                        else if (isFirestoreSynced) "Student profile verified & synchronized from Cloud Firestore"
                        else "Profile active (Local & Cloud Hybrid)",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                        color = if (isFirestoreSynced) Color(0xFF15803D) else Color(0xFF475569)
                    )
                }

                IconButton(
                    onClick = {
                        isLoadingFirestore = true
                        viewModel.fetchStudentProfileFromFirestore(student.studentId) { result ->
                            if (result != null) {
                                firestoreStudent = result
                                isFirestoreSynced = true
                            }
                            isLoadingFirestore = false
                        }
                    },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh from Firestore",
                        modifier = Modifier.size(16.dp),
                        tint = Color(0xFF64748B)
                    )
                }
            }
        }

        // Success alert when password changed with Auth update
        AnimatedVisibility(visible = passwordChangeMessage != null && passwordChangeSuccess) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFD1FAE5))
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF065F46))
                    Text(
                        text = passwordChangeMessage ?: "",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFF065F46)
                    )
                }
            }
        }

        // Student Profile Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(branch.primaryColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = branch.icon,
                        contentDescription = null,
                        tint = branch.primaryColor,
                        modifier = Modifier.size(42.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = currentStudent.name,
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )

                Text(
                    text = "Student Roll ID: ${currentStudent.studentId}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                BranchBadge(branchId = currentStudent.branchId, showFullName = true)
            }
        }

        // Personal & Academic Details (Fetched from Firestore)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    text = "Personal & Academic Credentials",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                ProfileInfoRow(
                    icon = Icons.Default.School,
                    label = "Branch / Specialization",
                    value = "${branch.fullName} (${branch.shortName})",
                    accentColor = branch.primaryColor
                )

                ProfileInfoRow(
                    icon = Icons.Default.Person,
                    label = "Academic Standing & Semester",
                    value = "Semester ${currentStudent.currentSemester} • Batch of ${currentStudent.enrollmentYear}",
                    accentColor = branch.primaryColor
                )

                ProfileInfoRow(
                    icon = Icons.Default.Cake,
                    label = "Date of Birth (Initial Security Code)",
                    value = currentStudent.dateOfBirth,
                    accentColor = branch.primaryColor
                )

                ProfileInfoRow(
                    icon = Icons.Default.Email,
                    label = "Institutional Email",
                    value = currentStudent.email,
                    accentColor = branch.primaryColor
                )

                ProfileInfoRow(
                    icon = Icons.Default.Phone,
                    label = "Registered Mobile",
                    value = currentStudent.phone,
                    accentColor = branch.primaryColor
                )

                ProfileInfoRow(
                    icon = Icons.Default.CheckCircle,
                    label = "Cumulative Grade Point Average (CGPA)",
                    value = "%.2f / 10.0".format(currentStudent.cgpa),
                    accentColor = Color(0xFF059669)
                )

                ProfileInfoRow(
                    icon = Icons.Default.CheckCircle,
                    label = "Instructional Attendance",
                    value = "%.1f%% (%d of %d hours attended)".format(overallAttendance, totalAttended, totalClasses),
                    accentColor = if (overallAttendance >= 75.0) Color(0xFF059669) else Color(0xFFDC2626)
                )
            }
        }

        // Branch Theme Visual Identity Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = branch.primaryColor.copy(alpha = 0.06f)
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, branch.primaryColor.copy(alpha = 0.25f))
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Palette, contentDescription = null, tint = branch.primaryColor)
                    Text(
                        text = "Assigned Branch Theme: ${branch.shortName}",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = branch.primaryColor
                    )
                }

                Text(
                    text = branch.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(24.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(branch.primaryColor)
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(24.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(branch.secondaryColor)
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(24.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(branch.surfaceGradientStart)
                    )
                }
            }
        }

        // Account Security & Authentication Update
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text(
                        text = "Authentication & Credentials Management",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Text(
                    text = "Updating your password will immediately propagate the credential update across your Firebase Authentication session, Cloud Firestore student document, and local encrypted store.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // 'Change Password' button that triggers an authentication update
                Button(
                    onClick = {
                        passwordChangeMessage = null
                        showPasswordDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = branch.primaryColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("change_password_button")
                ) {
                    Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Change Password (Trigger Auth Update)", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Institutional & Cyber Security Developer Footnote
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "RGMCET Academic System • Autonomous, Nandyal",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Developed by Cyber Security Student: D. Dasthagiri (22091A3301)",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Sign Out Button
        OutlinedButton(
            onClick = { viewModel.logout() },
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFDC2626)),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("profile_logout_button")
        ) {
            Icon(Icons.Default.ExitToApp, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Sign Out from RGMCET Portal", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ProfileInfoRow(
    icon: ImageVector,
    label: String,
    value: String,
    accentColor: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(accentColor.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
        }

        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

