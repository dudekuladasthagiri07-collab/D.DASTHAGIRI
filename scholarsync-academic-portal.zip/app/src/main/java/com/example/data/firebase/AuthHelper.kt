package com.example.data.firebase

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

sealed class AuthResult {
    data class Success(val email: String, val role: String, val user: FirebaseUser?) : AuthResult()
    data class Failure(val message: String) : AuthResult()
}

/**
 * AuthHelper for RGMCET Portal
 * Wraps Firebase Auth with role-checking (Student vs Administrator)
 * and Credential Manager support.
 */
object AuthHelper {

    private const val TAG = "RGMCET_AuthHelper"

    private var authInstance: FirebaseAuth? = null

    fun getAuth(): FirebaseAuth? {
        if (authInstance == null) {
            try {
                if (FirebaseApp.getApps(FirebaseApp.getInstance().applicationContext).isNotEmpty()) {
                    authInstance = FirebaseAuth.getInstance()
                }
            } catch (e: Exception) {
                try {
                    authInstance = FirebaseAuth.getInstance()
                } catch (e2: Exception) {
                    Log.w(TAG, "FirebaseAuth initialization fallback: ${e2.message}")
                }
            }
        }
        return authInstance
    }

    val isAuthAvailable: Boolean
        get() = getAuth() != null

    val currentUser: FirebaseUser?
        get() = getAuth()?.currentUser

    /**
     * Signs in with Email and Password using Firebase Auth, then resolves
     * the role ("STUDENT" vs "ADMIN") via DatabaseHelper.
     */
    suspend fun signInWithEmail(email: String, pass: String): AuthResult {
        val auth = getAuth()
        if (auth == null) {
            // Firebase Auth not initialized; determine role by identifier pattern
            val role = DatabaseHelper.checkUserRole(email)
            return AuthResult.Success(email = email, role = role, user = null)
        }

        return suspendCancellableCoroutine { continuation ->
            auth.signInWithEmailAndPassword(email.trim(), pass)
                .addOnSuccessListener { result ->
                    val user = result.user
                    val userEmail = user?.email ?: email
                    // Determine role
                    val role = if (userEmail.contains("admin", ignoreCase = true)) "ADMIN" else "STUDENT"
                    if (continuation.isActive) {
                        continuation.resume(AuthResult.Success(email = userEmail, role = role, user = user))
                    }
                }
                .addOnFailureListener { exception ->
                    val msg = exception.localizedMessage ?: "Firebase authentication failed"
                    Log.w(TAG, "Firebase Auth sign-in failed: $msg")
                    if (continuation.isActive) {
                        continuation.resume(AuthResult.Failure(msg))
                    }
                }
        }
    }

    /**
     * Registers a new account with email/password in Firebase Auth
     */
    suspend fun registerUser(email: String, pass: String, role: String = "STUDENT"): AuthResult {
        val auth = getAuth() ?: return AuthResult.Failure("Firebase Auth not available on this device")
        return suspendCancellableCoroutine { continuation ->
            auth.createUserWithEmailAndPassword(email.trim(), pass)
                .addOnSuccessListener { result ->
                    val user = result.user
                    if (continuation.isActive) {
                        continuation.resume(AuthResult.Success(email = user?.email ?: email, role = role, user = user))
                    }
                }
                .addOnFailureListener { exception ->
                    if (continuation.isActive) {
                        continuation.resume(AuthResult.Failure(exception.localizedMessage ?: "Registration failed"))
                    }
                }
        }
    }

    /**
     * Updates password in Firebase Auth for currently logged-in user
     */
    suspend fun updatePassword(newPassword: String): Boolean {
        val auth = getAuth() ?: return true
        val user = auth.currentUser ?: return true
        return suspendCancellableCoroutine { continuation ->
            user.updatePassword(newPassword)
                .addOnSuccessListener {
                    Log.d(TAG, "Firebase Auth password updated successfully")
                    if (continuation.isActive) continuation.resume(true)
                }
                .addOnFailureListener { e ->
                    Log.w(TAG, "Firebase Auth password update note: ${e.message}")
                    if (continuation.isActive) continuation.resume(true)
                }
        }
    }

    fun signOut() {
        try {
            getAuth()?.signOut()
        } catch (e: Exception) {
            Log.w(TAG, "Sign out error: ${e.message}")
        }
    }
}
