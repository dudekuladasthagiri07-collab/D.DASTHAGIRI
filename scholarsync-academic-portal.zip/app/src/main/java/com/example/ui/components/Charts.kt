package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AttendanceEntity
import com.example.data.model.UnitTestResultEntity

@Composable
fun AttendanceRingGauge(
    percentage: Double,
    modifier: Modifier = Modifier,
    sizeDp: Dp = 140.dp,
    strokeWidth: Dp = 14.dp,
    accentColor: Color = MaterialTheme.colorScheme.primary
) {
    val animatedProgress = remember { Animatable(0f) }
    val targetFraction = (percentage.coerceIn(0.0, 100.0) / 100.0).toFloat()

    LaunchedEffect(targetFraction) {
        animatedProgress.animateTo(
            targetValue = targetFraction,
            animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing)
        )
    }

    val statusColor = when {
        percentage >= 85.0 -> Color(0xFF10B981) // Emerald
        percentage >= 75.0 -> Color(0xFFF59E0B) // Amber
        else -> Color(0xFFEF4444) // Red Alert
    }

    Box(
        modifier = modifier.size(sizeDp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(sizeDp)) {
            val strokePx = strokeWidth.toPx()
            val diameter = size.minDimension - strokePx
            val topLeft = Offset(strokePx / 2f, strokePx / 2f)
            val arcSize = Size(diameter, diameter)

            // Background Track
            drawArc(
                color = Color.LightGray.copy(alpha = 0.25f),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            // Active Progress Arc
            drawArc(
                brush = Brush.sweepGradient(
                    0.0f to accentColor,
                    0.7f to statusColor,
                    1.0f to statusColor
                ),
                startAngle = 135f,
                sweepAngle = 270f * animatedProgress.value,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "%.1f%%".format(percentage),
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = statusColor
            )
            Text(
                text = if (percentage >= 75.0) "Eligible" else "Critical Shortage",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                color = if (percentage >= 75.0) MaterialTheme.colorScheme.onSurfaceVariant else Color(0xFFDC2626)
            )
        }
    }
}

@Composable
fun MonthlyAttendanceBarChart(
    monthlyValues: List<Double>,
    monthLabels: List<String> = listOf("Month 1", "Month 2", "Month 3", "Current"),
    modifier: Modifier = Modifier,
    accentColor: Color = MaterialTheme.colorScheme.primary
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Monthly Attendance Trajectory",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(Color(0xFFDC2626), CircleShape)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "75% Target Line",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height
                val barCount = monthlyValues.size.coerceAtLeast(1)
                val barSpacing = canvasWidth / (barCount * 2f)
                val barWidth = canvasWidth / (barCount * 2f)

                // 75% Target Dotted Line
                val targetY = canvasHeight * (1f - 0.75f)
                drawLine(
                    color = Color(0xFFEF4444),
                    start = Offset(0f, targetY),
                    end = Offset(canvasWidth, targetY),
                    strokeWidth = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                )

                monthlyValues.forEachIndexed { index, value ->
                    val fraction = (value / 100.0).coerceIn(0.0, 1.0).toFloat()
                    val barHeight = canvasHeight * fraction
                    val x = barSpacing + index * (barWidth + barSpacing)
                    val y = canvasHeight - barHeight

                    val barColor = if (value >= 75.0) accentColor else Color(0xFFEF4444)

                    // Draw rounded bar
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(barColor.copy(alpha = 0.85f), barColor)
                        ),
                        topLeft = Offset(x, y),
                        size = Size(barWidth, barHeight),
                        cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // X-axis labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                monthlyValues.forEachIndexed { index, value ->
                    val label = monthLabels.getOrElse(index) { "M${index + 1}" }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "%.1f%%".format(value),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (value >= 75.0) accentColor else Color(0xFFDC2626)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SubjectAttendanceBarChart(
    attendances: List<AttendanceEntity>,
    modifier: Modifier = Modifier,
    accentColor: Color = MaterialTheme.colorScheme.primary
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Subject-wise Attendance Distribution",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(12.dp))

            attendances.forEach { item ->
                val pct = item.attendancePercentage
                val isShortage = pct < 75.0
                val barColor = when {
                    pct >= 85.0 -> Color(0xFF10B981)
                    pct >= 75.0 -> accentColor
                    else -> Color(0xFFEF4444)
                }

                Column(modifier = Modifier.padding(vertical = 6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${item.subjectCode} - ${item.subjectName}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${item.attendedClasses}/${item.totalClasses} (%.1f%%)".format(pct),
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = barColor
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Progress Bar with 75% Marker
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .background(Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(5.dp))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth((pct / 100.0).coerceIn(0.0, 1.0).toFloat())
                                .height(10.dp)
                                .background(barColor, RoundedCornerShape(5.dp))
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun UnitTestTrendChart(
    unitTests: List<UnitTestResultEntity>,
    modifier: Modifier = Modifier,
    accentColor: Color = MaterialTheme.colorScheme.primary
) {
    if (unitTests.isEmpty()) return

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Performance Trajectory Across UT 1 to 5",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Max 20M per test",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Compute overall averages for UT 1 through UT 5
            val avgUt1 = unitTests.map { it.ut1Marks }.average()
            val avgUt2 = unitTests.map { it.ut2Marks }.average()
            val avgUt3 = unitTests.map { it.ut3Marks }.average()
            val avgUt4 = unitTests.map { it.ut4Marks }.average()
            val avgUt5 = unitTests.map { it.ut5Marks }.average()
            val testAverages = listOf(avgUt1, avgUt2, avgUt3, avgUt4, avgUt5)

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                val width = size.width
                val height = size.height
                val maxScore = 20.0f
                val stepX = width / 4f

                // Draw background grid lines at 5M, 10M, 15M, 20M
                for (mark in listOf(5f, 10f, 15f, 20f)) {
                    val y = height * (1f - mark / maxScore)
                    drawLine(
                        color = Color.LightGray.copy(alpha = 0.35f),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                // Points & Line Path
                val points = testAverages.mapIndexed { index, avg ->
                    val x = index * stepX
                    val y = height * (1f - (avg.toFloat() / maxScore).coerceIn(0f, 1f))
                    Offset(x, y)
                }

                val linePath = Path().apply {
                    points.forEachIndexed { index, offset ->
                        if (index == 0) moveTo(offset.x, offset.y) else lineTo(offset.x, offset.y)
                    }
                }

                // Fill area under path
                val fillPath = Path().apply {
                    addPath(linePath)
                    lineTo(points.last().x, height)
                    lineTo(points.first().x, height)
                    close()
                }

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        listOf(accentColor.copy(alpha = 0.35f), accentColor.copy(alpha = 0.05f))
                    )
                )

                // Stroke Path
                drawPath(
                    path = linePath,
                    color = accentColor,
                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                )

                // Circles at points
                points.forEach { point ->
                    drawCircle(color = Color.White, radius = 5.dp.toPx(), center = point)
                    drawCircle(color = accentColor, radius = 3.dp.toPx(), center = point)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // X-axis labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("UT 1", "UT 2", "UT 3", "UT 4", "UT 5").forEachIndexed { index, name ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "%.1f/20".format(testAverages[index]),
                            style = MaterialTheme.typography.labelSmall,
                            color = accentColor
                        )
                    }
                }
            }
        }
    }
}

/**
 * Data model for comparing a student's score against class average in a unit test.
 */
data class SubjectUnitTestComparison(
    val subjectCode: String,
    val subjectName: String,
    val studentScore: Double,
    val classAverage: Double,
    val classHighest: Double = 20.0,
    val maxMarks: Double = 20.0
) {
    val difference: Double get() = studentScore - classAverage
    val isAboveAverage: Boolean get() = difference >= 0.0
}

/**
 * Grouped Bar Chart component visualizing student marks side-by-side against class averages for each subject.
 */
@Composable
fun UnitTestComparisonBarChart(
    comparisons: List<SubjectUnitTestComparison>,
    testTitle: String,
    modifier: Modifier = Modifier,
    accentColor: Color = MaterialTheme.colorScheme.primary,
    classAverageColor: Color = MaterialTheme.colorScheme.secondary
) {
    val animProgress = remember(testTitle, comparisons) { Animatable(0f) }

    LaunchedEffect(testTitle, comparisons) {
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing)
        )
    }

    val avgStudent = if (comparisons.isNotEmpty()) comparisons.map { it.studentScore }.average() else 0.0
    val avgClass = if (comparisons.isNotEmpty()) comparisons.map { it.classAverage }.average() else 0.0
    val delta = avgStudent - avgClass

    val density = LocalDensity.current
    val textPaintStudent = remember(accentColor, density) {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = accentColor.toArgb()
            textSize = with(density) { 10.sp.toPx() }
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            textAlign = android.graphics.Paint.Align.CENTER
        }
    }
    val textPaintClass = remember(classAverageColor, density) {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = classAverageColor.toArgb()
            textSize = with(density) { 10.sp.toPx() }
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.NORMAL)
            textAlign = android.graphics.Paint.Align.CENTER
        }
    }
    val textPaintAxis = remember(density) {
        android.graphics.Paint().apply {
            isAntiAlias = true
            color = android.graphics.Color.GRAY
            textSize = with(density) { 9.sp.toPx() }
            textAlign = android.graphics.Paint.Align.RIGHT
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Title & Description
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "$testTitle Performance vs Class Average",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Side-by-side comparison per subject (Max 20 marks)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Summary Stats Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(accentColor, CircleShape)
                    )
                    Text(
                        text = "Student: %.1f".format(avgStudent),
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = accentColor
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(classAverageColor, CircleShape)
                    )
                    Text(
                        text = "Class Avg: %.1f".format(avgClass),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (delta >= 0) Color(0xFFD1FAE5) else Color(0xFFFEE2E2)
                ) {
                    Text(
                        text = if (delta >= 0) "+%.1f Above Avg".format(delta) else "%.1f Below Avg".format(delta),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (delta >= 0) Color(0xFF065F46) else Color(0xFF991B1B),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Bar Chart Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                val yAxisSteps = listOf(20.0, 15.0, 10.0, 5.0, 0.0)
                val topPadding = 24.dp.toPx()
                val bottomPadding = 4.dp.toPx()
                val availableHeight = size.height - topPadding - bottomPadding
                val leftAxisWidth = 32.dp.toPx()
                val contentWidth = size.width - leftAxisWidth

                // Horizontal dashed grid lines
                yAxisSteps.forEach { stepVal ->
                    val stepY = topPadding + ((20.0 - stepVal) / 20.0 * availableHeight).toFloat()
                    drawLine(
                        color = Color.LightGray.copy(alpha = 0.45f),
                        start = Offset(leftAxisWidth, stepY),
                        end = Offset(size.width, stepY),
                        strokeWidth = 1.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
                    )
                    drawContext.canvas.nativeCanvas.drawText(
                        "${stepVal.toInt()}M",
                        leftAxisWidth - 6.dp.toPx(),
                        stepY + 3.dp.toPx(),
                        textPaintAxis
                    )
                }

                if (comparisons.isNotEmpty()) {
                    val groupWidth = contentWidth / comparisons.size
                    val maxBarWidth = 16.dp.toPx()
                    val barWidth = (groupWidth * 0.30f).coerceIn(6.dp.toPx(), maxBarWidth)
                    val barGap = 3.dp.toPx()
                    val bottomY = topPadding + availableHeight

                    comparisons.forEachIndexed { index, comp ->
                        val groupCenterX = leftAxisWidth + (index + 0.5f) * groupWidth
                        val studentScore = comp.studentScore.coerceIn(0.0, 20.0)
                        val classAvg = comp.classAverage.coerceIn(0.0, 20.0)

                        val studentHeight = (studentScore / 20.0 * availableHeight * animProgress.value).toFloat()
                        val classAvgHeight = (classAvg / 20.0 * availableHeight * animProgress.value).toFloat()

                        val studentX = groupCenterX - barWidth - (barGap / 2f)
                        val classX = groupCenterX + (barGap / 2f)

                        // Draw Student Bar
                        val studentTopY = bottomY - studentHeight
                        drawRoundRect(
                            brush = Brush.verticalGradient(
                                listOf(accentColor, accentColor.copy(alpha = 0.75f))
                            ),
                            topLeft = Offset(studentX, studentTopY),
                            size = Size(barWidth, studentHeight),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )

                        // Draw Class Average Bar
                        val classTopY = bottomY - classAvgHeight
                        drawRoundRect(
                            brush = Brush.verticalGradient(
                                listOf(classAverageColor, classAverageColor.copy(alpha = 0.65f))
                            ),
                            topLeft = Offset(classX, classTopY),
                            size = Size(barWidth, classAvgHeight),
                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                        )

                        // Values above bars
                        if (animProgress.value > 0.45f) {
                            drawContext.canvas.nativeCanvas.drawText(
                                "%.1f".format(studentScore),
                                studentX + barWidth / 2f,
                                studentTopY - 4.dp.toPx(),
                                textPaintStudent
                            )
                            drawContext.canvas.nativeCanvas.drawText(
                                "%.1f".format(classAvg),
                                classX + barWidth / 2f,
                                classTopY - 4.dp.toPx(),
                                textPaintClass
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // X-axis subject labels
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 32.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                comparisons.forEach { comp ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = comp.subjectCode,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
