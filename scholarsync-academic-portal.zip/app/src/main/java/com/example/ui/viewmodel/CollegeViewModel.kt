package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.CollegeDatabase
import com.example.data.firebase.DatabaseHelper
import com.example.data.model.AdminEntity
import com.example.data.model.AttendanceEntity
import com.example.data.model.BranchId
import com.example.data.model.SemesterResultEntity
import com.example.data.model.StudentEntity
import com.example.data.model.SyllabusEntity
import com.example.data.model.UnitTestResultEntity
import com.example.data.repository.CollegeRepository
import com.example.security.SecurityUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class AuthState {
    object LoggedOut : AuthState()
    data class StudentLoggedIn(val student: StudentEntity, val requiresPasswordChange: Boolean) : AuthState()
    data class AdminLoggedIn(val admin: AdminEntity) : AuthState()
}

@OptIn(ExperimentalCoroutinesApi::class)
class CollegeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CollegeRepository
    val allStudents: StateFlow<List<StudentEntity>>

    init {
        val db = CollegeDatabase.getDatabase(application, viewModelScope)
        repository = CollegeRepository(db.collegeDao())
        allStudents = repository.getAllStudents().stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
        // Ensure default data & admin is present
        viewModelScope.launch(Dispatchers.IO) {
            repository.ensureAdminExists()
        }
    }

    private val _authState = MutableStateFlow<AuthState>(AuthState.LoggedOut)
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError.asStateFlow()

    private val _currentStudentId = MutableStateFlow<String?>(null)
    val currentStudentId: StateFlow<String?> = _currentStudentId.asStateFlow()

    // Active branch selection (e.g. for exploring syllabus or filtered admin views)
    private val _selectedBranchCode = MutableStateFlow("CSE")
    val selectedBranchCode: StateFlow<String> = _selectedBranchCode.asStateFlow()

    private val _selectedSemester = MutableStateFlow(4)
    val selectedSemester: StateFlow<Int> = _selectedSemester.asStateFlow()

    // Real-time observed student entity
    val activeStudent: StateFlow<StudentEntity?> = _currentStudentId.flatMapLatest { id ->
        if (id != null) repository.getStudent(id) else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Real-time student attendance
    val attendanceList: StateFlow<List<AttendanceEntity>> = _currentStudentId.flatMapLatest { id ->
        if (id != null) repository.getAttendanceForStudent(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Real-time unit test results
    val unitTestList: StateFlow<List<UnitTestResultEntity>> = _currentStudentId.flatMapLatest { id ->
        if (id != null) repository.getUnitTestsForStudent(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Real-time semester results
    val semesterResults: StateFlow<List<SemesterResultEntity>> = _currentStudentId.flatMapLatest { id ->
        if (id != null) repository.getSemesterResultsForStudent(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Syllabus for current branch and semester
    val syllabusList: StateFlow<List<SyllabusEntity>> = combine(
        _selectedBranchCode,
        _selectedSemester
    ) { branch, sem ->
        branch to sem
    }.flatMapLatest { (branch, sem) ->
        repository.getSyllabusForBranchAndSem(branch, sem)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All syllabus entries for admin
    val allSyllabusList: StateFlow<List<SyllabusEntity>> = repository.getAllSyllabus().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun setSelectedBranch(branchCode: String) {
        _selectedBranchCode.value = branchCode
    }

    fun setSelectedSemester(semester: Int) {
        _selectedSemester.value = semester
    }

    // --- Authentication ---

    fun loginStudent(studentIdInput: String, passwordOrDobInput: String) {
        viewModelScope.launch {
            _loginError.value = null
            val id = studentIdInput.trim().uppercase()
            val inputPass = passwordOrDobInput.trim()

            if (id.isEmpty() || inputPass.isEmpty()) {
                _loginError.value = "Please enter both Student ID and Password/DOB"
                return@launch
            }

            val student = withContext(Dispatchers.IO) {
                repository.getStudentDirect(id)
            }

            if (student == null) {
                _loginError.value = "Student ID not found in institutional database"
                return@launch
            }

            // Verify password or DOB
            val normalizedInput = SecurityUtils.normalizeDob(inputPass)
            val isValidStandard = SecurityUtils.verifyPassword(inputPass, student.passwordHash, student.salt)
            val isValidDob = SecurityUtils.verifyPassword(normalizedInput, student.passwordHash, student.salt)

            if (isValidStandard || isValidDob) {
                _currentStudentId.value = student.studentId
                _selectedBranchCode.value = student.branchId
                _selectedSemester.value = student.currentSemester
                _authState.value = AuthState.StudentLoggedIn(
                    student = student,
                    requiresPasswordChange = student.isFirstLogin
                )
            } else {
                _loginError.value = "Incorrect password or date of birth. (First time? Use your DOB e.g. 15-08-2004)"
            }
        }
    }

    fun loginAdmin(adminIdInput: String, passwordInput: String) {
        viewModelScope.launch {
            _loginError.value = null
            val id = adminIdInput.trim().uppercase()
            val pass = passwordInput.trim()

            if (id.isEmpty() || pass.isEmpty()) {
                _loginError.value = "Please enter Admin ID and Passcode"
                return@launch
            }

            val admin = withContext(Dispatchers.IO) {
                repository.getAdmin(id)
            }

            if (admin != null && SecurityUtils.verifyPassword(pass, admin.passwordHash, admin.salt)) {
                _authState.value = AuthState.AdminLoggedIn(admin)
            } else {
                _loginError.value = "Invalid Admin Credentials"
            }
        }
    }

    /**
     * Unified Login supporting Email/Password, Student Roll Number, or Admin ID
     * with automatic role checking (Admin vs Student) and Firebase Auth.
     */
    fun loginUniversal(identifier: String, pass: String) {
        viewModelScope.launch {
            _loginError.value = null
            val rawId = identifier.trim()
            val inputPass = pass.trim()

            if (rawId.isEmpty() || inputPass.isEmpty()) {
                _loginError.value = "Please enter your Email/ID and Password"
                return@launch
            }

            // Role checking: determine if this is an Admin or Student
            val isEmail = rawId.contains("@")
            val detectedRole = com.example.data.firebase.DatabaseHelper.checkUserRole(rawId)

            if (detectedRole == "ADMIN" || rawId.startsWith("ADMIN", ignoreCase = true)) {
                // Try Admin Login
                val admin = withContext(Dispatchers.IO) {
                    if (isEmail) repository.getAdminByEmail(rawId) else repository.getAdmin(rawId.uppercase())
                }
                if (admin != null && SecurityUtils.verifyPassword(inputPass, admin.passwordHash, admin.salt)) {
                    _authState.value = AuthState.AdminLoggedIn(admin)
                    return@launch
                } else if (admin != null) {
                    _loginError.value = "Invalid administrator passcode"
                    return@launch
                }
            }

            // Student Login (or fallthrough if admin not matched)
            val student = withContext(Dispatchers.IO) {
                if (isEmail) repository.getStudentByEmail(rawId) else repository.getStudentDirect(rawId.uppercase())
            }

            if (student != null) {
                val normalizedInput = SecurityUtils.normalizeDob(inputPass)
                val isValidStandard = SecurityUtils.verifyPassword(inputPass, student.passwordHash, student.salt)
                val isValidDob = SecurityUtils.verifyPassword(normalizedInput, student.passwordHash, student.salt)

                if (isValidStandard || isValidDob) {
                    _currentStudentId.value = student.studentId
                    _selectedBranchCode.value = student.branchId
                    _selectedSemester.value = student.currentSemester
                    _authState.value = AuthState.StudentLoggedIn(
                        student = student,
                        requiresPasswordChange = student.isFirstLogin
                    )
                    return@launch
                } else {
                    _loginError.value = "Incorrect password or date of birth (DD-MM-YYYY)"
                    return@launch
                }
            }

            // If not found in local DB, attempt Firebase Auth
            if (isEmail && com.example.data.firebase.AuthHelper.isAuthAvailable) {
                when (val result = com.example.data.firebase.AuthHelper.signInWithEmail(rawId, inputPass)) {
                    is com.example.data.firebase.AuthResult.Success -> {
                        if (result.role == "ADMIN") {
                            val dummyAdmin = AdminEntity("ADMIN_FB", "Portal Administrator", "", "", rawId, "ADMIN")
                            _authState.value = AuthState.AdminLoggedIn(dummyAdmin)
                        } else {
                            val fallbackStudent = withContext(Dispatchers.IO) {
                                repository.getStudentDirect("22091A3301") ?: repository.getStudentDirect("CYBER202403")
                            }
                            if (fallbackStudent != null) {
                                _currentStudentId.value = fallbackStudent.studentId
                                _authState.value = AuthState.StudentLoggedIn(fallbackStudent, false)
                            }
                        }
                        return@launch
                    }
                    is com.example.data.firebase.AuthResult.Failure -> {
                        _loginError.value = result.message
                        return@launch
                    }
                }
            }

            _loginError.value = "User not found. For students, use Roll No (e.g. 22091A3301) or Email. For admin, use ADMIN001."
        }
    }

    fun completeFirstLoginPasswordChange(newPassword: String, onResult: (Boolean, String?) -> Unit) {
        val studentId = _currentStudentId.value
        if (studentId == null) {
            onResult(false, "No active student session")
            return
        }
        if (newPassword.length < 6) {
            onResult(false, "Password must be at least 6 characters")
            return
        }

        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.updateStudentPassword(studentId, newPassword)
            }
            val updated = withContext(Dispatchers.IO) {
                repository.getStudentDirect(studentId)
            }
            if (updated != null) {
                _authState.value = AuthState.StudentLoggedIn(updated, requiresPasswordChange = false)
                onResult(true, null)
            } else {
                onResult(false, "Failed to update profile")
            }
        }
    }

    fun fetchStudentProfileFromFirestore(studentId: String, onResult: (StudentEntity?) -> Unit) {
        viewModelScope.launch {
            val firestoreStudent = withContext(Dispatchers.IO) {
                com.example.data.firebase.DatabaseHelper.getStudentFromFirestore(studentId)
            }
            if (firestoreStudent != null) {
                onResult(firestoreStudent)
            } else {
                // Fallback to local Room DB if network/firestore not populated
                val localStudent = withContext(Dispatchers.IO) {
                    repository.getStudentDirect(studentId)
                }
                onResult(localStudent)
            }
        }
    }

    fun changePasswordFromProfile(oldPass: String, newPass: String, onResult: (Boolean, String?) -> Unit) {
        changePasswordWithAuthUpdate(oldPass, newPass, onResult)
    }

    /**
     * Changes password and triggers an authentication update in both Room, Firestore, and Firebase Auth.
     */
    fun changePasswordWithAuthUpdate(oldPass: String, newPass: String, onResult: (Boolean, String?) -> Unit) {
        val studentId = _currentStudentId.value ?: return
        if (newPass.length < 6) {
            onResult(false, "New password must be at least 6 characters")
            return
        }

        viewModelScope.launch {
            val student = withContext(Dispatchers.IO) { repository.getStudentDirect(studentId) }
            if (student == null) {
                onResult(false, "Student record not found")
                return@launch
            }
            val validOld = SecurityUtils.verifyPassword(oldPass, student.passwordHash, student.salt) ||
                    SecurityUtils.verifyPassword(SecurityUtils.normalizeDob(oldPass), student.passwordHash, student.salt)

            if (!validOld) {
                onResult(false, "Current password is incorrect")
                return@launch
            }

            // 1. Update Room DB and sync to Firestore
            withContext(Dispatchers.IO) {
                repository.updateStudentPassword(studentId, newPass)
            }

            // 2. Trigger Firebase Auth password update
            withContext(Dispatchers.IO) {
                try {
                    com.example.data.firebase.AuthHelper.updatePassword(newPass)
                } catch (e: Exception) {
                    android.util.Log.w("CollegeViewModel", "Firebase Auth password update note: ${e.message}")
                }
            }

            // 3. Refresh active student state
            val updated = withContext(Dispatchers.IO) { repository.getStudentDirect(studentId) }
            if (updated != null) {
                _authState.value = AuthState.StudentLoggedIn(updated, requiresPasswordChange = false)
            }

            onResult(true, null)
        }
    }

    fun logout() {
        _currentStudentId.value = null
        _authState.value = AuthState.LoggedOut
        _loginError.value = null
    }

    // --- Admin Operations ---

    fun adminCreateStudent(
        studentId: String,
        name: String,
        dob: String,
        branchId: String,
        semester: Int,
        email: String,
        phone: String,
        cgpa: Double,
        onComplete: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    repository.createStudent(
                        studentId = studentId,
                        name = name,
                        dateOfBirth = dob,
                        branchId = branchId,
                        semester = semester,
                        email = email,
                        phone = phone,
                        enrollmentYear = 2024,
                        cgpa = cgpa
                    )
                }
                onComplete(true, null)
            } catch (e: Exception) {
                onComplete(false, e.localizedMessage ?: "Failed to create student")
            }
        }
    }

    fun adminResetStudentPassword(studentId: String, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            val success = withContext(Dispatchers.IO) {
                repository.resetStudentPasswordToDob(studentId)
            }
            onComplete(success)
        }
    }

    fun adminSaveAttendance(attendance: AttendanceEntity, onComplete: () -> Unit) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.saveAttendance(attendance)
            }
            onComplete()
        }
    }

    fun adminSaveUnitTest(unitTest: UnitTestResultEntity, onComplete: () -> Unit) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.saveUnitTest(unitTest)
            }
            onComplete()
        }
    }

    fun adminSaveSemesterResult(result: SemesterResultEntity, onComplete: () -> Unit) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.saveSemesterResult(result)
            }
            onComplete()
        }
    }

    fun adminSaveSyllabus(syllabus: SyllabusEntity, onComplete: () -> Unit) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.saveSyllabus(syllabus)
            }
            onComplete()
        }
    }

    fun adminDeleteSyllabus(syllabus: SyllabusEntity) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.deleteSyllabus(syllabus)
            }
        }
    }

    /**
     * Fetches syllabus document data directly from Cloud Firestore for a specific branch and semester,
     * synchronizing fresh records into the local Room database.
     */
    fun fetchSyllabusFromFirestore(
        branchId: String,
        semester: Int,
        onResult: (List<SyllabusEntity>, Boolean) -> Unit = { _, _ -> }
    ) {
        viewModelScope.launch {
            val list: List<SyllabusEntity> = withContext(Dispatchers.IO) {
                try {
                    DatabaseHelper.fetchSyllabusFromFirestore(branchId, semester)
                } catch (e: Exception) {
                    emptyList<SyllabusEntity>()
                }
            }
            if (list.isNotEmpty()) {
                withContext(Dispatchers.IO) {
                    for (item in list) {
                        repository.saveSyllabus(item)
                    }
                }
                onResult(list, true)
            } else {
                onResult(emptyList(), false)
            }
        }
    }
}
