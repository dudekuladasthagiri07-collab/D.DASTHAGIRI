package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Grade
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BranchId
import com.example.data.model.StudentEntity
import com.example.ui.viewmodel.CollegeViewModel

@Composable
fun SemesterResultsScreen(
    student: StudentEntity,
    viewModel: CollegeViewModel,
    modifier: Modifier = Modifier
) {
    val branch = BranchId.fromCode(student.branchId)
    val allResults by viewModel.semesterResults.collectAsState()

    // Available semesters from student history
    val availableSemesters = remember(allResults) {
        val sems = allResults.map { it.semester }.distinct().sorted()
        if (sems.isEmpty()) listOf(student.currentSemester) else sems
    }

    var selectedSemester by remember(availableSemesters) {
        mutableIntStateOf(student.currentSemester)
    }

    val currentSemResults = allResults.filter { it.semester == selectedSemester }

    val totalCredits = currentSemResults.sumOf { it.credits }
    val totalGradeWeighted = currentSemResults.sumOf { it.credits * it.gradePoints }
    val semSgpa = if (totalCredits > 0) totalGradeWeighted.toDouble() / totalCredits.toDouble() else 0.0

    val isAllPassed = currentSemResults.isNotEmpty() && currentSemResults.all { it.isPassed }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Semester Selector Chips (Allows viewing previous semester results!)
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "Select Semester Record:",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(1, 2, 3, 4, 5, 6, 7, 8).forEach { sem ->
                    val hasData = allResults.any { it.semester == sem }
                    FilterChip(
                        selected = selectedSemester == sem,
                        onClick = { selectedSemester = sem },
                        label = {
                            Text(
                                text = "Semester $sem" + if (sem == student.currentSemester) " (Current)" else "",
                                fontWeight = if (selectedSemester == sem) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = branch.primaryColor,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        // Summary Card with SGPA, CGPA, Credits & Status
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Grade, contentDescription = null, tint = branch.primaryColor, modifier = Modifier.size(18.dp))
                            Text(
                                text = "SEMESTER $selectedSemester OFFICIAL GRADE SHEET",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                                color = branch.primaryColor
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${branch.fullName}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isAllPassed) Color(0xFFD1FAE5) else Color(0xFFFEF3C7)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                if (isAllPassed) Icons.Default.CheckCircle else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (isAllPassed) Color(0xFF065F46) else Color(0xFF92400E),
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (isAllPassed) "SEMESTER PASSED" else "PENDING",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isAllPassed) Color(0xFF065F46) else Color(0xFF92400E)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Semester SGPA",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "%.2f".format(semSgpa),
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = branch.primaryColor
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Cumulative CGPA",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "%.2f".format(student.cgpa),
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFFF59E0B)
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Earned Credits",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "$totalCredits",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF10B981)
                        )
                    }
                }
            }
        }

        // Detailed Results Table (includes Internal, External, Total, Grade, Grade points, Credits, U.U. open elective)
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Semester $selectedSemester Marks & Grade Details",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${currentSemResults.size} Courses",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("semester_results_table_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                val horizontalScroll = rememberScrollState()

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(horizontalScroll)
                ) {
                    // Table Header
                    Row(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TableCell(text = "Subject Code & Name", width = 240.dp, isHeader = true)
                        TableCell(text = "Type", width = 90.dp, isHeader = true)
                        TableCell(text = "Internal (40)", width = 95.dp, isHeader = true)
                        TableCell(text = "External (60)", width = 95.dp, isHeader = true)
                        TableCell(text = "Total (100)", width = 85.dp, isHeader = true)
                        TableCell(text = "Grade", width = 75.dp, isHeader = true)
                        TableCell(text = "Points", width = 70.dp, isHeader = true)
                        TableCell(text = "Credits", width = 70.dp, isHeader = true)
                        TableCell(text = "Status", width = 85.dp, isHeader = true)
                    }

                    currentSemResults.forEachIndexed { index, res ->
                        val rowBg = if (index % 2 == 0) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)

                        Row(
                            modifier = Modifier
                                .background(rowBg)
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.width(240.dp)) {
                                Text(
                                    text = res.subjectName,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                    maxLines = 2
                                )
                                Text(
                                    text = res.subjectCode,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = branch.primaryColor
                                )
                            }

                            // Course Type (Regular vs U.U. Open Elective)
                            Box(modifier = Modifier.width(90.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (res.isOpenElective) Color(0xFFF3E8FF) else Color(0xFFF1F5F9)
                                ) {
                                    Text(
                                        text = if (res.isOpenElective) "U.U. Open" else "Core",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = if (res.isOpenElective) Color(0xFF7E22CE) else Color(0xFF475569),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            TableCell(text = "${res.internalMarks}", width = 95.dp)
                            TableCell(text = "${res.externalMarks}", width = 95.dp)
                            TableCell(text = "${res.totalMarks}", width = 85.dp)

                            // Grade Pill
                            Box(modifier = Modifier.width(75.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = when (res.grade) {
                                        "O", "A+" -> Color(0xFFD1FAE5)
                                        "A", "B+" -> Color(0xFFE0E7FF)
                                        "B", "C" -> Color(0xFFFEF3C7)
                                        else -> Color(0xFFFEE2E2)
                                    }
                                ) {
                                    Text(
                                        text = res.grade,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = when (res.grade) {
                                            "O", "A+" -> Color(0xFF065F46)
                                            "A", "B+" -> Color(0xFF3730A3)
                                            "B", "C" -> Color(0xFF92400E)
                                            else -> Color(0xFF991B1B)
                                        },
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            TableCell(text = "${res.gradePoints}", width = 70.dp)
                            TableCell(text = "${res.credits}", width = 70.dp)

                            // Pass / Fail status
                            Text(
                                text = if (res.isPassed) "PASS" else "FAIL",
                                modifier = Modifier.width(85.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (res.isPassed) Color(0xFF059669) else Color(0xFFDC2626)
                            )
                        }
                    }

                    if (currentSemResults.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No grade sheet published for Semester $selectedSemester yet.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
