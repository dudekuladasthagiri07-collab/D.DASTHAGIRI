package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "students",
    indices = [Index(value = ["studentId"], unique = true)]
)
data class StudentEntity(
    @PrimaryKey
    val studentId: String,
    val name: String,
    val dateOfBirth: String, // format: "DD-MM-YYYY" (used as temporary initial password)
    val passwordHash: String,
    val salt: String,
    val isFirstLogin: Boolean = true,
    val branchId: String,
    val currentSemester: Int = 4,
    val email: String,
    val phone: String,
    val enrollmentYear: Int = 2024,
    val cgpa: Double = 8.5
)

@Entity(
    tableName = "attendance",
    indices = [Index(value = ["studentId", "subjectCode"], unique = true)]
)
data class AttendanceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val studentId: String,
    val subjectName: String,
    val subjectCode: String,
    val totalClasses: Int,
    val attendedClasses: Int,
    val previousMonthPercentage: Double,
    val monthlyHistoryCsv: String = "75.0,80.0,82.5,85.0" // Csv of past months for trend chart
) {
    val absentClasses: Int
        get() = (totalClasses - attendedClasses).coerceAtLeast(0)

    val attendancePercentage: Double
        get() = if (totalClasses > 0) {
            (attendedClasses.toDouble() / totalClasses.toDouble()) * 100.0
        } else 0.0

    val isShortage: Boolean
        get() = attendancePercentage < 75.0
}

@Entity(
    tableName = "unit_tests",
    indices = [Index(value = ["studentId", "subjectCode"], unique = true)]
)
data class UnitTestResultEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val studentId: String,
    val subjectName: String,
    val subjectCode: String,
    val maxMarks: Double = 20.0,
    val ut1Marks: Double,
    val ut2Marks: Double,
    val ut3Marks: Double,
    val ut4Marks: Double,
    val ut5Marks: Double
) {
    val totalMarks: Double
        get() = ut1Marks + ut2Marks + ut3Marks + ut4Marks + ut5Marks

    val maxTotalMarks: Double
        get() = maxMarks * 5.0

    val averageMarks: Double
        get() = totalMarks / 5.0

    val percentage: Double
        get() = if (maxTotalMarks > 0) (totalMarks / maxTotalMarks) * 100.0 else 0.0
}

@Entity(
    tableName = "semester_results",
    indices = [Index(value = ["studentId", "semester", "subjectCode"], unique = true)]
)
data class SemesterResultEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val studentId: String,
    val semester: Int,
    val subjectName: String,
    val subjectCode: String,
    val internalMarks: Int, // out of 40
    val externalMarks: Int, // out of 60
    val totalMarks: Int,    // out of 100
    val grade: String,      // O, A+, A, B+, B, C, F
    val gradePoints: Int,   // 10, 9, 8, 7, 6, 5, 0
    val credits: Int,       // 3, 4
    val sgpa: Double,
    val isOpenElective: Boolean = false // U.U. / Open Elective subject indicator
) {
    val isPassed: Boolean
        get() = grade != "F" && totalMarks >= 40
}

@Entity(
    tableName = "syllabus",
    indices = [Index(value = ["branchId", "semester", "subjectCode"], unique = true)]
)
data class SyllabusEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val branchId: String,
    val semester: Int,
    val subjectName: String,
    val subjectCode: String,
    val credits: Int,
    val hoursLtp: String = "3-1-0",
    val isOpenElective: Boolean = false, // University Open Subject (U.U.)
    val module1: String,
    val module2: String,
    val module3: String,
    val module4: String,
    val module5: String,
    val evaluationScheme: String = "UT: 20M, Mid Term: 20M, End Semester: 60M (Total 100M)"
)

@Entity(
    tableName = "admins",
    indices = [Index(value = ["adminId"], unique = true)]
)
data class AdminEntity(
    @PrimaryKey
    val adminId: String,
    val name: String,
    val passwordHash: String,
    val salt: String,
    val email: String = "admin@collegeportal.edu",
    val role: String = "ADMIN"
)
