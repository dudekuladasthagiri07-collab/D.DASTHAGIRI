package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AttendanceEntity
import com.example.data.model.BranchId
import com.example.data.model.StudentEntity
import com.example.ui.components.AttendanceRingGauge
import com.example.ui.components.AttendanceShortageWarning
import com.example.ui.components.MonthlyAttendanceBarChart
import com.example.ui.components.SubjectAttendanceBarChart
import com.example.ui.viewmodel.CollegeViewModel

/**
 * Utility function that compares an attendance percentage against a threshold (e.g., 75.0%).
 * Returns true if attendance is below the mandatory requirement, indicating low attendance.
 */
fun isLowAttendance(percentage: Double, threshold: Double = 75.0): Boolean {
    return percentage < threshold
}

/**
 * Compares an attendance percentage against a threshold and calculates deficit details.
 */
data class AttendanceThresholdResult(
    val percentage: Double,
    val threshold: Double,
    val isBelowRequirement: Boolean,
    val deficit: Double,
    val consecutiveClassesNeeded: Int
)

fun evaluateAttendanceThreshold(
    percentage: Double,
    totalClasses: Int = 0,
    attendedClasses: Int = 0,
    threshold: Double = 75.0
): AttendanceThresholdResult {
    val isBelow = isLowAttendance(percentage, threshold)
    val deficit = if (isBelow) threshold - percentage else 0.0
    val classesNeeded = if (isBelow && totalClasses > 0 && threshold < 100.0) {
        val tRatio = threshold / 100.0
        val numerator = (tRatio * totalClasses) - attendedClasses
        val denominator = 1.0 - tRatio
        val calculated = Math.ceil(numerator / denominator).toInt()
        maxOf(calculated, 1)
    } else 0

    return AttendanceThresholdResult(
        percentage = percentage,
        threshold = threshold,
        isBelowRequirement = isBelow,
        deficit = deficit,
        consecutiveClassesNeeded = classesNeeded
    )
}

/**
 * High-visibility 'Low Attendance' warning indicator displayed when attendance is below requirement.
 */
@Composable
fun LowAttendanceWarningIndicator(
    percentage: Double,
    threshold: Double = 75.0,
    totalClasses: Int = 0,
    attendedClasses: Int = 0,
    modifier: Modifier = Modifier
) {
    val result = remember(percentage, threshold, totalClasses, attendedClasses) {
        evaluateAttendanceThreshold(percentage, totalClasses, attendedClasses, threshold)
    }

    if (result.isBelowRequirement) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .testTag("low_attendance_warning_indicator"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
            border = androidx.compose.foundation.BorderStroke(2.dp, Color(0xFFDC2626)),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFDC2626)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Low Attendance Alert",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "LOW ATTENDANCE ALERT",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp
                                ),
                                color = Color(0xFF991B1B)
                            )

                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = Color(0xFFDC2626)
                            ) {
                                Text(
                                    text = "ACTION REQUIRED",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 9.sp),
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = "Current Attendance: %.1f%% (Required: %.0f%%)".format(result.percentage, result.threshold),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF7F1D1D)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFEE2E2),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Deficit: -%.1f%%".format(result.deficit),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFFB91C1C)
                            )
                            Text(
                                text = "• Below RGMCET Examination Condonation Threshold",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF7F1D1D)
                            )
                        }

                        if (result.consecutiveClassesNeeded > 0) {
                            Text(
                                text = "Recovery Target: You must attend the next ${result.consecutiveClassesNeeded} consecutive classes without absence to achieve the mandatory ${result.threshold.toInt()}%% eligibility.",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                color = Color(0xFF991B1B)
                            )
                        } else {
                            Text(
                                text = "You are currently ineligible for End-Semester University examinations without approved medical condonation from the Academic Dean.",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF991B1B)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AttendanceScreen(
    student: StudentEntity,
    viewModel: CollegeViewModel,
    modifier: Modifier = Modifier
) {
    val branch = BranchId.fromCode(student.branchId)
    val attendanceList by viewModel.attendanceList.collectAsState()

    var searchQuery by remember { mutableStateOf("") }

    val filteredList = attendanceList.filter {
        it.subjectName.contains(searchQuery, ignoreCase = true) ||
                it.subjectCode.contains(searchQuery, ignoreCase = true)
    }

    val totalAttended = attendanceList.sumOf { it.attendedClasses }
    val totalClasses = attendanceList.sumOf { it.totalClasses }
    val overallAttendance = if (totalClasses > 0) (totalAttended.toDouble() / totalClasses) * 100.0 else 0.0

    val previousMonthOverall = if (attendanceList.isNotEmpty()) {
        attendanceList.map { it.previousMonthPercentage }.average()
    } else 0.0

    // Compute monthly trajectory across 4 months from csv data
    val monthlyProgression = remember(attendanceList) {
        if (attendanceList.isNotEmpty()) {
            val count = 4
            val sums = DoubleArray(count)
            var validRows = 0
            attendanceList.forEach { entity ->
                val parts = entity.monthlyHistoryCsv.split(",").mapNotNull { it.trim().toDoubleOrNull() }
                if (parts.size >= count) {
                    for (i in 0 until count) {
                        sums[i] += parts[i]
                    }
                    validRows++
                }
            }
            if (validRows > 0) {
                sums.map { it / validRows }
            } else {
                listOf(78.0, 80.5, previousMonthOverall, overallAttendance)
            }
        } else {
            listOf(75.0, 80.0, 82.0, 85.0)
        }
    }

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Overview Banner with Ring Gauge & Month Comparisons
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = branch.primaryColor,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "OFFICIAL ATTENDANCE RECORD",
                            style = MaterialTheme.typography.labelMedium.copy(
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            color = branch.primaryColor
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "Overall Attendance: %.1f%%".format(overallAttendance),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Previous-Month Attendance: %.1f%%".format(previousMonthOverall),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    val delta = overallAttendance - previousMonthOverall
                    Text(
                        text = if (delta >= 0) "▲ +%.1f%% vs last month".format(delta) else "▼ %.1f%% vs last month".format(delta),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = if (delta >= 0) Color(0xFF059669) else Color(0xFFDC2626)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                AttendanceRingGauge(
                    percentage = overallAttendance,
                    sizeDp = 120.dp,
                    strokeWidth = 12.dp,
                    accentColor = branch.primaryColor
                )
            }
        }

        // High-Visibility Low Attendance Warning Indicator
        LowAttendanceWarningIndicator(
            percentage = overallAttendance,
            threshold = 75.0,
            totalClasses = totalClasses,
            attendedClasses = totalAttended
        )

        // Attendance Shortage Visual Warning
        AttendanceShortageWarning(overallPercentage = overallAttendance)

        // Graphical Format 1: Monthly Attendance Trajectory Chart
        MonthlyAttendanceBarChart(
            monthlyValues = monthlyProgression,
            monthLabels = listOf("Aug", "Sep", "Oct (Prev)", "Current"),
            accentColor = branch.primaryColor
        )

        // Graphical Format 2: Subject-wise Comparison Chart
        SubjectAttendanceBarChart(
            attendances = attendanceList,
            accentColor = branch.primaryColor
        )

        // Attendance Table Section
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Subject Attendance Table",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                Text(
                    text = "${filteredList.size} Courses",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Search filter
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by subject name or code...") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("attendance_search_input")
            )

            // Responsive Horizontal Scroll Table
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("attendance_table_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                val horizontalScroll = rememberScrollState()

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(horizontalScroll)
                ) {
                    // Table Header
                    Row(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TableCell(text = "Subject Code & Name", width = 230.dp, isHeader = true)
                        TableCell(text = "Total Classes", width = 100.dp, isHeader = true)
                        TableCell(text = "Attended", width = 90.dp, isHeader = true)
                        TableCell(text = "Absent", width = 80.dp, isHeader = true)
                        TableCell(text = "Attendance %", width = 110.dp, isHeader = true)
                        TableCell(text = "Prev-Month %", width = 110.dp, isHeader = true)
                        TableCell(text = "Status", width = 110.dp, isHeader = true)
                    }

                    // Table Body Rows
                    filteredList.forEachIndexed { index, item ->
                        val pct = item.attendancePercentage
                        val isShortage = pct < 75.0
                        val rowBg = if (index % 2 == 0) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)

                        Row(
                            modifier = Modifier
                                .testTag("attendance_row_${item.subjectCode}")
                                .background(rowBg)
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.width(230.dp)) {
                                Text(
                                    text = item.subjectName,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                    maxLines = 2
                                )
                                Text(
                                    text = item.subjectCode,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = branch.primaryColor
                                )
                            }

                            TableCell(text = "${item.totalClasses}", width = 100.dp)
                            TableCell(text = "${item.attendedClasses}", width = 90.dp)
                            TableCell(text = "${item.absentClasses}", width = 80.dp)

                            // Attendance % Pill
                            Box(modifier = Modifier.width(110.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = when {
                                        pct >= 85.0 -> Color(0xFFD1FAE5)
                                        pct >= 75.0 -> Color(0xFFFEF3C7)
                                        else -> Color(0xFFFEE2E2)
                                    }
                                ) {
                                    Text(
                                        text = "%.1f%%".format(pct),
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = when {
                                            pct >= 85.0 -> Color(0xFF065F46)
                                            pct >= 75.0 -> Color(0xFF92400E)
                                            else -> Color(0xFF991B1B)
                                        },
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            // Prev Month %
                            TableCell(text = "%.1f%%".format(item.previousMonthPercentage), width = 110.dp)

                            // Eligibility Status
                            Box(modifier = Modifier.width(110.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isShortage) Icons.Default.Warning else Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = if (isShortage) Color(0xFFDC2626) else Color(0xFF059669),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = if (isShortage) "Shortage" else "Normal",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                        color = if (isShortage) Color(0xFFDC2626) else Color(0xFF059669)
                                    )
                                }
                            }
                        }
                    }

                    if (filteredList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No matching subjects found.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TableCell(
    text: String,
    width: androidx.compose.ui.unit.Dp,
    isHeader: Boolean = false
) {
    Text(
        text = text,
        modifier = Modifier.width(width),
        style = if (isHeader) MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
        else MaterialTheme.typography.bodySmall,
        color = if (isHeader) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
    )
}
