package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.example.data.model.BranchId

/**
 * Mapping of branch IDs to custom ColorScheme objects for light mode.
 * - Cyber Security gets a tech-focused deep blue theme.
 * - Civil gets a slate theme.
 * - Other engineering disciplines get tailored, high-contrast M3 themes.
 */
val BranchLightColorSchemes: Map<BranchId, ColorScheme> = mapOf(
    BranchId.CYBER to lightColorScheme(
        primary = Color(0xFF0F3E75),       // Tech-focused Deep Blue
        onPrimary = Color.White,
        primaryContainer = Color(0xFFD0E4FF),
        onPrimaryContainer = Color(0xFF001D36),
        secondary = Color(0xFF0284C7),     // Tech Sky/Cyan Blue
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFE0F2FE),
        onSecondaryContainer = Color(0xFF03446A),
        tertiary = Color(0xFF0369A1),
        onTertiary = Color.White,
        background = Color(0xFFF8FAFC),
        onBackground = Color(0xFF0F172A),
        surface = Color(0xFFFFFFFF),
        onSurface = Color(0xFF0F172A),
        surfaceVariant = Color(0xFFF1F5F9),
        onSurfaceVariant = Color(0xFF334155),
        outline = Color(0xFFCBD5E1),
        outlineVariant = Color(0xFFE2E8F0)
    ),
    BranchId.CIVIL to lightColorScheme(
        primary = Color(0xFF475569),       // Slate theme (Slate 600)
        onPrimary = Color.White,
        primaryContainer = Color(0xFFE2E8F0),
        onPrimaryContainer = Color(0xFF0F172A),
        secondary = Color(0xFF64748B),     // Medium Slate (Slate 500)
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFF1F5F9),
        onSecondaryContainer = Color(0xFF1E293B),
        tertiary = Color(0xFF94A3B8),
        onTertiary = Color(0xFF0F172A),
        background = Color(0xFFF8FAFC),
        onBackground = Color(0xFF0F172A),
        surface = Color(0xFFFFFFFF),
        onSurface = Color(0xFF0F172A),
        surfaceVariant = Color(0xFFF1F5F9),
        onSurfaceVariant = Color(0xFF475569),
        outline = Color(0xFFCBD5E1),
        outlineVariant = Color(0xFFE2E8F0)
    ),
    BranchId.CSE to lightColorScheme(
        primary = Color(0xFF1E40AF),       // Deep Institutional Royal Blue
        onPrimary = Color.White,
        primaryContainer = Color(0xFFDBEAFE),
        onPrimaryContainer = Color(0xFF1E3A8A),
        secondary = Color(0xFF0284C7),     // Sky Blue
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFE0F2FE),
        onSecondaryContainer = Color(0xFF075985),
        tertiary = Color(0xFF3B82F6),
        onTertiary = Color.White,
        background = Color(0xFFF8FAFC),
        onBackground = Color(0xFF0F172A),
        surface = Color(0xFFFFFFFF),
        onSurface = Color(0xFF0F172A),
        surfaceVariant = Color(0xFFF1F5F9),
        onSurfaceVariant = Color(0xFF475569),
        outline = Color(0xFFCBD5E1),
        outlineVariant = Color(0xFFE2E8F0)
    ),
    BranchId.AIML to lightColorScheme(
        primary = Color(0xFF6D28D9),       // Neural Violet
        onPrimary = Color.White,
        primaryContainer = Color(0xFFEDE9FE),
        onPrimaryContainer = Color(0xFF4C1D95),
        secondary = Color(0xFFA855F7),     // Electric Purple
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFF3E8FF),
        onSecondaryContainer = Color(0xFF581C87),
        tertiary = Color(0xFF7C3AED),
        onTertiary = Color.White,
        background = Color(0xFFFAF5FF),
        onBackground = Color(0xFF1E1B4B),
        surface = Color(0xFFFFFFFF),
        onSurface = Color(0xFF1E1B4B),
        surfaceVariant = Color(0xFFF5F3FF),
        onSurfaceVariant = Color(0xFF4C1D95),
        outline = Color(0xFFDDD6FE),
        outlineVariant = Color(0xFFEDE9FE)
    ),
    BranchId.DATA_SCIENCE to lightColorScheme(
        primary = Color(0xFF0369A1),       // Deep Ocean Blue
        onPrimary = Color.White,
        primaryContainer = Color(0xFFE0F2FE),
        onPrimaryContainer = Color(0xFF0C4A6E),
        secondary = Color(0xFF0EA5E9),     // Cyan/Ocean
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFF0F9FF),
        onSecondaryContainer = Color(0xFF0369A1),
        tertiary = Color(0xFF0284C7),
        onTertiary = Color.White,
        background = Color(0xFFF8FAFC),
        onBackground = Color(0xFF0F172A),
        surface = Color(0xFFFFFFFF),
        onSurface = Color(0xFF0F172A),
        surfaceVariant = Color(0xFFF0F9FF),
        onSurfaceVariant = Color(0xFF0369A1),
        outline = Color(0xFFBAE6FD),
        outlineVariant = Color(0xFFE0F2FE)
    ),
    BranchId.ECE to lightColorScheme(
        primary = Color(0xFF991B1B),       // Signal Crimson
        onPrimary = Color.White,
        primaryContainer = Color(0xFFFEE2E2),
        onPrimaryContainer = Color(0xFF7F1D1D),
        secondary = Color(0xFFEF4444),     // Bright Red
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFFEF2F2),
        onSecondaryContainer = Color(0xFF991B1B),
        tertiary = Color(0xFFDC2626),
        onTertiary = Color.White,
        background = Color(0xFFFFFBFB),
        onBackground = Color(0xFF1F1515),
        surface = Color(0xFFFFFFFF),
        onSurface = Color(0xFF1F1515),
        surfaceVariant = Color(0xFFFEF2F2),
        onSurfaceVariant = Color(0xFF7F1D1D),
        outline = Color(0xFFFECACA),
        outlineVariant = Color(0xFFFEE2E2)
    ),
    BranchId.EEE to lightColorScheme(
        primary = Color(0xFFB45309),       // Electric Amber
        onPrimary = Color.White,
        primaryContainer = Color(0xFFFEF3C7),
        onPrimaryContainer = Color(0xFF78350F),
        secondary = Color(0xFFF59E0B),     // Gold/Amber
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFFFFBEB),
        onSecondaryContainer = Color(0xFF92400E),
        tertiary = Color(0xFFD97706),
        onTertiary = Color.White,
        background = Color(0xFFFFFDF5),
        onBackground = Color(0xFF1F1B12),
        surface = Color(0xFFFFFFFF),
        onSurface = Color(0xFF1F1B12),
        surfaceVariant = Color(0xFFFFFBEB),
        onSurfaceVariant = Color(0xFF92400E),
        outline = Color(0xFFFDE68A),
        outlineVariant = Color(0xFFFEF3C7)
    ),
    BranchId.MECHANICAL to lightColorScheme(
        primary = Color(0xFF334155),       // Precision Steel Slate
        onPrimary = Color.White,
        primaryContainer = Color(0xFFE2E8F0),
        onPrimaryContainer = Color(0xFF0F172A),
        secondary = Color(0xFF64748B),     // Steel 500
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFF1F5F9),
        onSecondaryContainer = Color(0xFF1E293B),
        tertiary = Color(0xFF475569),
        onTertiary = Color.White,
        background = Color(0xFFF8FAFC),
        onBackground = Color(0xFF0F172A),
        surface = Color(0xFFFFFFFF),
        onSurface = Color(0xFF0F172A),
        surfaceVariant = Color(0xFFF1F5F9),
        onSurfaceVariant = Color(0xFF334155),
        outline = Color(0xFFCBD5E1),
        outlineVariant = Color(0xFFE2E8F0)
    )
)

/**
 * Mapping of branch IDs to custom ColorScheme objects for dark mode.
 */
val BranchDarkColorSchemes: Map<BranchId, ColorScheme> = mapOf(
    BranchId.CYBER to darkColorScheme(
        primary = Color(0xFF38BDF8),       // Tech Sky Light
        onPrimary = Color(0xFF001D36),
        primaryContainer = Color(0xFF0F3E75),
        onPrimaryContainer = Color(0xFFD0E4FF),
        secondary = Color(0xFF7DD3FC),
        onSecondary = Color(0xFF003554),
        background = Color(0xFF0A192F),     // Deep Tech Navy
        onBackground = Color(0xFFE2E8F0),
        surface = Color(0xFF0F2744),
        onSurface = Color(0xFFF1F5F9),
        surfaceVariant = Color(0xFF1E3A5F),
        onSurfaceVariant = Color(0xFF94A3B8)
    ),
    BranchId.CIVIL to darkColorScheme(
        primary = Color(0xFF94A3B8),       // Light Slate
        onPrimary = Color(0xFF0F172A),
        primaryContainer = Color(0xFF334155),
        onPrimaryContainer = Color(0xFFE2E8F0),
        secondary = Color(0xFFCBD5E1),
        onSecondary = Color(0xFF1E293B),
        background = Color(0xFF0F172A),     // Slate Dark Background
        onBackground = Color(0xFFF1F5F9),
        surface = Color(0xFF1E293B),
        onSurface = Color(0xFFF1F5F9),
        surfaceVariant = Color(0xFF334155),
        onSurfaceVariant = Color(0xFF94A3B8)
    ),
    BranchId.CSE to darkColorScheme(
        primary = Color(0xFF60A5FA),
        onPrimary = Color(0xFF1E3A8A),
        secondary = Color(0xFF38BDF8),
        onSecondary = Color(0xFF075985),
        background = Color(0xFF0F172A),
        surface = Color(0xFF1E293B),
        onBackground = Color(0xFFF1F5F9),
        onSurface = Color(0xFFF1F5F9)
    ),
    BranchId.AIML to darkColorScheme(
        primary = Color(0xFFA78BFA),
        onPrimary = Color(0xFF4C1D95),
        secondary = Color(0xFFC084FC),
        onSecondary = Color(0xFF581C87),
        background = Color(0xFF1E1B4B),
        surface = Color(0xFF2E1065),
        onBackground = Color(0xFFF3E8FF),
        onSurface = Color(0xFFF3E8FF)
    ),
    BranchId.DATA_SCIENCE to darkColorScheme(
        primary = Color(0xFF38BDF8),
        onPrimary = Color(0xFF0C4A6E),
        secondary = Color(0xFF7DD3FC),
        onSecondary = Color(0xFF0369A1),
        background = Color(0xFF0C243C),
        surface = Color(0xFF13385C),
        onBackground = Color(0xFFE0F2FE),
        onSurface = Color(0xFFE0F2FE)
    ),
    BranchId.ECE to darkColorScheme(
        primary = Color(0xFFF87171),
        onPrimary = Color(0xFF7F1D1D),
        secondary = Color(0xFFFCA5A5),
        onSecondary = Color(0xFF991B1B),
        background = Color(0xFF2B1010),
        surface = Color(0xFF451A1A),
        onBackground = Color(0xFFFEE2E2),
        onSurface = Color(0xFFFEE2E2)
    ),
    BranchId.EEE to darkColorScheme(
        primary = Color(0xFFFBBF24),
        onPrimary = Color(0xFF78350F),
        secondary = Color(0xFFFCD34D),
        onSecondary = Color(0xFF92400E),
        background = Color(0xFF281C06),
        surface = Color(0xFF442F0B),
        onBackground = Color(0xFFFEF3C7),
        onSurface = Color(0xFFFEF3C7)
    ),
    BranchId.MECHANICAL to darkColorScheme(
        primary = Color(0xFF94A3B8),
        onPrimary = Color(0xFF0F172A),
        secondary = Color(0xFFCBD5E1),
        onSecondary = Color(0xFF1E293B),
        background = Color(0xFF0F172A),
        surface = Color(0xFF1E293B),
        onBackground = Color(0xFFF1F5F9),
        onSurface = Color(0xFFF1F5F9)
    )
)

/**
 * Mapping of branch ID code strings (e.g. "CYBER", "CIVIL", "CSE") to ColorScheme objects.
 */
val BranchIdCodeToColorScheme: Map<String, ColorScheme> = BranchLightColorSchemes.entries.associate { (branch, scheme) ->
    branch.code to scheme
}

/**
 * Resolves the appropriate ColorScheme based on the student's assigned branch.
 */
fun getBranchColorScheme(branch: BranchId?, darkTheme: Boolean = false): ColorScheme {
    val b = branch ?: BranchId.CYBER
    return if (darkTheme) {
        BranchDarkColorSchemes[b] ?: BranchDarkColorSchemes.getValue(BranchId.CYBER)
    } else {
        BranchLightColorSchemes[b] ?: BranchLightColorSchemes.getValue(BranchId.CYBER)
    }
}

/**
 * Resolves the appropriate ColorScheme based on branch code string.
 */
fun getBranchColorScheme(branchCode: String?, darkTheme: Boolean = false): ColorScheme {
    val branch = branchCode?.let { BranchId.fromCode(it) }
    return getBranchColorScheme(branch, darkTheme)
}

@Composable
fun CollegePortalTheme(
    branch: BranchId? = null,
    branchCode: String? = null,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val resolvedBranch = branch ?: branchCode?.let { BranchId.fromCode(it) }
    val colorScheme = getBranchColorScheme(resolvedBranch, darkTheme)

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
